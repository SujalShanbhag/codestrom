import React from 'react';
import { Plus, Clock, Save, Trash2, Calendar, Award, Star, ListChecks, Brain, BookOpen } from 'lucide-react';
import { motion } from 'framer-motion';
import { db } from '../firebase';
import { collection, addDoc, onSnapshot, query, where, deleteDoc, doc, updateDoc, serverTimestamp, getDoc, setDoc } from 'firebase/firestore';
import { cn } from '../lib/utils';

interface StudyPlannerProps {
  userId: string;
}

export const StudyPlanner: React.FC<StudyPlannerProps> = ({ userId }) => {
  const [timetable, setTimetable] = React.useState<any[]>([]);
  const [courses, setCourses] = React.useState<any[]>([]);
  const [certs, setCerts] = React.useState<any[]>([]);
  const [newSlot, setNewSlot] = React.useState({ day: 'Monday', subject: '', startTime: '09:00' });
  const [showAddSlot, setShowAddSlot] = React.useState(false);
  const [logHours, setLogHours] = React.useState({ courseId: '', hours: 1 });

  React.useEffect(() => {
    if (!userId) return;

    const unsubTimetable = onSnapshot(collection(db, 'users', userId, 'timetable'), (snap) => {
      setTimetable(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    const unsubCourses = onSnapshot(collection(db, 'users', userId, 'courses'), (snap) => {
      setCourses(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    const unsubCerts = onSnapshot(collection(db, 'users', userId, 'certifications'), (snap) => {
      setCerts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => {
      unsubTimetable();
      unsubCourses();
      unsubCerts();
    };
  }, [userId]);

  const addTimetableSlot = async () => {
    if (!newSlot.subject) return;
    await addDoc(collection(db, 'users', userId, 'timetable'), newSlot);
    setNewSlot({ day: 'Monday', subject: '', startTime: '09:00' });
    setShowAddSlot(false);
  };

  const deleteSlot = async (id: string) => {
    await deleteDoc(doc(db, 'users', userId, 'timetable', id));
  };

  const handleLogHours = async () => {
    if (!logHours.courseId) return;
    const course = courses.find(c => c.id === logHours.courseId);
    if (!course) return;

    const newHours = (course.hoursStudied || 0) + Number(logHours.hours);
    const newPoints = (course.totalPoints || 0) + (logHours.hours * 10);
    const newLevel = Math.floor(newPoints / 100) + 1;

    await updateDoc(doc(db, 'users', userId, 'courses', logHours.courseId), {
      hoursStudied: newHours,
      totalPoints: newPoints,
      level: newLevel
    });

    // Award certificate if level 5 reached and not already awarded
    if (newLevel >= 5 && !certs.some(c => c.courseName === course.name)) {
      await addDoc(collection(db, 'users', userId, 'certifications'), {
        courseName: course.name,
        dateAwarded: new Date().toISOString(),
        pointsAchieved: newPoints
      });
    }

    // Award Badge if level 10 reached
    if (newLevel >= 10) {
      const userRef = doc(db, 'users', userId);
      const userDoc = await getDoc(userRef);
      if (userDoc.exists()) {
        const currentBadges = userDoc.data().badges || [];
        const badgeName = `${course.name} Master`;
        if (!currentBadges.includes(badgeName)) {
          await updateDoc(userRef, {
            badges: [...currentBadges, badgeName]
          });
        }
      }
    }

    // Log Daily Activity
    const today = new Date().toISOString().split('T')[0];
    const activityRef = doc(db, 'users', userId, 'activity', today);
    const activityDoc = await getDoc(activityRef);
    
    if (activityDoc.exists()) {
      await updateDoc(activityRef, {
        hours: (activityDoc.data().hours || 0) + Number(logHours.hours)
      });
    } else {
      await setDoc(activityRef, {
        date: today,
        hours: Number(logHours.hours)
      });
    }

    setLogHours({ courseId: '', hours: 1 });
  };

  const addCourse = async (name: string) => {
    if (!name) return;
    await addDoc(collection(db, 'users', userId, 'courses'), {
      name,
      totalPoints: 0,
      level: 1,
      hoursStudied: 0,
      completed: false
    });
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const suggestions = [
    { name: 'Computer Science', color: 'bg-blue-500' },
    { name: 'Modern History', color: 'bg-amber-500' },
    { name: 'Organic Chemistry', color: 'bg-emerald-500' },
    { name: 'Philosophy', color: 'bg-purple-500' },
    { name: 'Calculus III', color: 'bg-rose-500' }
  ];

  const certificateTypes = [
    { title: 'Level 5: Specialist', desc: 'Reach Level 5 in any core subject.' },
    { title: 'Level 10: Mastery', desc: 'Reach Level 10 and obtain the "Master" badge.' },
    { title: 'Level 20: Scholar', desc: 'Achieve significant depth with Level 20 expertise.' }
  ];

  return (
    <div className="space-y-8 pb-20">
      {/* Header Info */}
      <div className="bg-slate-900 rounded-[2.5rem] p-8 md:p-12 text-white relative overflow-hidden">
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-black tracking-tight mb-4 italic serif">Plan Your Journey</h1>
          <p className="text-slate-400 text-lg max-w-xl">Set your schedule, track your hours, and earn industry-recognized digital certifications as you master new skills.</p>
        </div>
        <div className="absolute top-1/2 right-12 -translate-y-1/2 hidden lg:block opacity-20">
          <Calendar className="w-64 h-64 rotate-12" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Explorer & Suggestions */}
        <div className="lg:col-span-8 space-y-8">
          {/* Suggested section */}
          <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Star className="w-20 h-20" />
            </div>
            <div className="mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Brain className="w-5 h-5 text-indigo-600" />
                Suggested Subjects
              </h2>
              <p className="text-slate-500 text-sm">Quickly add from common curriculum paths.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              {suggestions.map((s) => (
                <button
                  key={s.name}
                  onClick={() => addCourse(s.name)}
                  className="px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm font-bold hover:border-indigo-200 hover:text-indigo-600 transition-all flex items-center gap-2 group"
                >
                  <div className={cn("w-2 h-2 rounded-full", s.color)} />
                  {s.name}
                  <Plus className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </div>
          </section>

          {/* Courses Tracking */}
          <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500" />
                My Courses
              </h2>
              <button 
                onClick={() => {
                  const name = prompt('Course Name?');
                  if (name) addCourse(name);
                }}
                className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all"
              >
                <Plus className="w-4 h-4" />
                Manual Add
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {courses.map(course => (
                <div key={course.id} className="p-5 bg-slate-50 rounded-2xl border border-slate-100 group">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-black text-slate-900 leading-tight mb-1">{course.name}</h3>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded uppercase tracking-wider">Level {course.level}</span>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{course.totalPoints} XP</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-black text-slate-900">{course.hoursStudied || 0}h</p>
                      <p className="text-[9px] text-slate-400 uppercase tracking-widest font-black">Logged Time</p>
                    </div>
                  </div>
                  
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-6">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(course.totalPoints % 100)}%` }}
                      className="bg-indigo-600 h-full transition-all duration-1000" 
                    />
                  </div>

                  <button 
                    onClick={async () => {
                      const newStatus = !course.completed;
                      await updateDoc(doc(db, 'users', userId, 'courses', course.id), { completed: newStatus });
                      if (newStatus) {
                        const userRef = doc(db, 'users', userId);
                        const userDoc = await getDoc(userRef);
                        if (userDoc.exists()) {
                          const currentBadges = userDoc.data().badges || [];
                          const badgeName = `${course.name} Graduate`;
                          if (!currentBadges.includes(badgeName)) {
                            await updateDoc(userRef, { badges: [...currentBadges, badgeName] });
                          }
                        }
                      }
                    }}
                    className={cn(
                      "w-full py-2.5 rounded-xl text-xs font-black transition-all border uppercase tracking-widest",
                      course.completed 
                        ? "bg-emerald-500 text-white border-emerald-500 shadow-lg shadow-emerald-100" 
                        : "bg-white text-slate-500 border-slate-100 hover:border-indigo-100 hover:text-indigo-600"
                    )}
                  >
                    {course.completed ? 'Mastered ✓' : 'Mark Completion'}
                  </button>
                </div>
              ))}
              {courses.length === 0 && (
                <div className="col-span-full py-12 text-center bg-slate-50 rounded-3xl border border-dashed border-slate-200 text-slate-400">
                  <BookOpen className="w-8 h-8 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">No courses yet. Select a suggestion above!</p>
                </div>
              )}
            </div>
          </section>
        </div>

        {/* Right Column: Tracking & Certs */}
        <div className="lg:col-span-4 space-y-8">
          {/* Logging Widget */}
          <section className="bg-indigo-600 rounded-3xl p-8 text-white shadow-xl">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Log Activity
            </h3>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Select Subject</label>
                <select 
                  className="w-full bg-indigo-500/50 border-none rounded-xl text-sm px-4 py-3 placeholder-white/50 focus:ring-2 focus:ring-white/20"
                  value={logHours.courseId}
                  onChange={e => setLogHours({ ...logHours, courseId: e.target.value })}
                >
                  <option value="" className="text-slate-900">Choose a course...</option>
                  {courses.map(c => <option key={c.id} value={c.id} className="text-slate-900">{c.name}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Hours Studied</label>
                <input 
                  type="number" 
                  min="0.5" 
                  step="0.5"
                  className="w-full bg-indigo-500/50 border-none rounded-xl text-sm px-4 py-3 focus:ring-2 focus:ring-white/20"
                  value={logHours.hours}
                  onChange={e => setLogHours({ ...logHours, hours: Number(e.target.value) })}
                />
              </div>
              <button 
                onClick={handleLogHours}
                disabled={!logHours.courseId}
                className="w-full bg-white text-indigo-600 py-4 rounded-xl font-black text-sm hover:bg-slate-50 transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100"
              >
                Log Session
              </button>
            </div>
          </section>

          {/* Certifications Catalog */}
          <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" />
              Available Certs
            </h2>
            <div className="space-y-4">
              {certificateTypes.map((type) => (
                <div key={type.title} className="p-4 rounded-2xl border border-slate-50 bg-slate-50/50">
                  <h4 className="text-sm font-bold text-slate-900 mb-1">{type.title}</h4>
                  <p className="text-[11px] text-slate-500 leading-tight">{type.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Earned Certs */}
          {certs.length > 0 && (
            <section className="bg-amber-400 rounded-3xl p-8 text-amber-950">
              <h2 className="text-xl font-bold flex items-center gap-2 mb-6 italic serif">
                <Award className="w-5 h-5" />
                Your Wall of Fame
              </h2>
              <div className="space-y-4">
                {certs.map(cert => (
                  <div key={cert.id} className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl border border-amber-200">
                    <p className="text-[9px] font-black uppercase tracking-widest opacity-60 mb-1">Academic Credential</p>
                    <h3 className="font-black text-lg text-slate-900 leading-tight">{cert.courseName}</h3>
                    <div className="flex justify-between items-center mt-3 pt-3 border-t border-amber-100">
                      <span className="text-[10px] font-bold">{new Date(cert.dateAwarded).toLocaleDateString()}</span>
                      <span className="text-[10px] font-black bg-amber-200 px-2 py-0.5 rounded">VERIFIED</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>

      {/* Timetable remains below */}
      <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Calendar className="w-6 h-6 text-indigo-600" />
              Study Timetable
            </h2>
            <p className="text-slate-500 text-sm mt-1">Plan your weekly routine to stay consistent.</p>
          </div>
          <button 
            onClick={() => setShowAddSlot(!showAddSlot)}
            className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            <Plus className="w-4 h-4" />
            Add Slot
          </button>
        </div>

        {showAddSlot && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="mb-8 p-6 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-1 md:grid-cols-4 gap-4"
          >
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Day</label>
              <select 
                className="w-full bg-white border-slate-200 rounded-xl text-sm px-4 py-2.5"
                value={newSlot.day}
                onChange={e => setNewSlot({ ...newSlot, day: e.target.value })}
              >
                {days.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Subject</label>
              <input 
                type="text" 
                placeholder="e.g. Physics"
                className="w-full bg-white border-slate-200 rounded-xl text-sm px-4 py-2.5"
                value={newSlot.subject}
                onChange={e => setNewSlot({ ...newSlot, subject: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Time</label>
              <input 
                type="time" 
                className="w-full bg-white border-slate-200 rounded-xl text-sm px-4 py-2.5"
                value={newSlot.startTime}
                onChange={e => setNewSlot({ ...newSlot, startTime: e.target.value })}
              />
            </div>
            <div className="flex items-end">
              <button 
                onClick={addTimetableSlot}
                className="w-full bg-indigo-600 text-white py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Slot
              </button>
            </div>
          </motion.div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
          {days.map(day => (
            <div key={day} className="space-y-3">
              <div className="bg-slate-100 py-2 rounded-xl text-center">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-widest">{day.slice(0, 3)}</span>
              </div>
              <div className="space-y-2">
                {timetable.filter(slot => slot.day === day).sort((a, b) => a.startTime.localeCompare(b.startTime)).map(slot => (
                  <div key={slot.id} className="group relative p-3 bg-white border border-slate-100 rounded-xl shadow-sm hover:border-indigo-200 transition-all">
                    <p className="text-[10px] font-bold text-indigo-600 mb-1 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {slot.startTime}
                    </p>
                    <p className="text-xs font-bold text-slate-800 truncate">{slot.subject}</p>
                    <button 
                      onClick={() => deleteSlot(slot.id)}
                      className="absolute -top-1 -right-1 p-1 bg-white border border-slate-100 rounded-full text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
