import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface StudyData {
  summary: string;
  keyPoints: string[];
  quizzes: {
    mcqs: Array<{ question: string; options: string[]; answer: string }>;
    shortQuestions: string[];
    longQuestions: string[];
  };
  flashcards: Array<{ front: string; back: string }>;
  gamification: {
    suggestedLevel: 'Beginner' | 'Intermediate' | 'Advanced';
    suggestedBadges: string[];
    studyMantra: string;
  };
  animeAmbiance: {
    theme: string;
    videoDescription: string;
    youtubeKeyword: string;
  };
  searchExamples: string[];
}

export async function generateStudyMaterial(pdfText: string): Promise<StudyData> {
  const prompt = `
    Based on the following extracted text from a PDF, generate a massive structured learning experience.
    
    TEXT:
    ${pdfText}
    
    TASK:
    Generate a JSON object containing:
    1. A clear, concise, student-friendly summary.
    2. 10 important key points (concepts, definitions, formulas).
    3. A comprehensive practice quiz with:
       - 10 Multiple Choice Questions (MCQs) with 4 options each and the correct answer.
       - 5 Short Answer Questions.
       - 5 Long/Descriptive Questions.
    4. At least 12 flashcards where 'front' is the question/concept and 'back' is the answer/explanation.
    5. Gamification: A suggested level, list of badges, and a "Study Mantra" for motivation.
    6. "Anime Ambiance": Suggest an anime-style study environment theme (e.g. "Rainy Library in Tokyo", "Space Station Observatory", "Coastal Cafe at Sunset") and a YouTube keyword to find matching Lo-Fi/Study music.
    7. 5 example search queries.
    
    OUTPUT FORMAT:
    JSON only.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        required: ["summary", "keyPoints", "quizzes", "flashcards", "gamification", "animeAmbiance", "searchExamples"],
        properties: {
          summary: { type: Type.STRING },
          keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
          quizzes: {
            type: Type.OBJECT,
            required: ["mcqs", "shortQuestions", "longQuestions"],
            properties: {
              mcqs: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: ["question", "options", "answer"],
                  properties: {
                    question: { type: Type.STRING },
                    options: { type: Type.ARRAY, items: { type: Type.STRING } },
                    answer: { type: Type.STRING }
                  }
                }
              },
              shortQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
              longQuestions: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          },
          flashcards: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              required: ["front", "back"],
              properties: {
                front: { type: Type.STRING },
                back: { type: Type.STRING }
              }
            }
          },
          gamification: {
            type: Type.OBJECT,
            required: ["suggestedLevel", "suggestedBadges", "studyMantra"],
            properties: {
              suggestedLevel: { type: Type.STRING, enum: ["Beginner", "Intermediate", "Advanced"] },
              suggestedBadges: { type: Type.ARRAY, items: { type: Type.STRING } },
              studyMantra: { type: Type.STRING }
            }
          },
          animeAmbiance: {
            type: Type.OBJECT,
            required: ["theme", "videoDescription", "youtubeKeyword"],
            properties: {
              theme: { type: Type.STRING },
              videoDescription: { type: Type.STRING },
              youtubeKeyword: { type: Type.STRING }
            }
          },
          searchExamples: { type: Type.ARRAY, items: { type: Type.STRING } }
        }
      }
    }
  });

  const text = response.text || '{}';
  return JSON.parse(text) as StudyData;
}
