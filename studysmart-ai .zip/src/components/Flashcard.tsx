import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface FlashcardProps {
  front: string;
  back: string;
}

export const Flashcard: React.FC<FlashcardProps> = ({ front, back }) => {
  const [isFlipped, setIsFlipped] = React.useState(false);

  return (
    <div 
      className="perspective-1000 w-full h-64 cursor-pointer"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="relative w-full h-full transition-all duration-500 preserve-3d"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 260, damping: 20 }}
      >
        {/* Front */}
        <div className="absolute inset-0 backface-hidden flex items-center justify-center p-6 bg-white border-2 border-indigo-100 rounded-2xl shadow-sm">
          <p className="text-gray-800 text-center font-medium text-lg leading-relaxed">
            {front}
          </p>
        </div>

        {/* Back */}
        <div 
          className="absolute inset-0 backface-hidden flex items-center justify-center p-6 bg-indigo-50 border-2 border-indigo-200 rounded-2xl shadow-sm rotate-y-180"
        >
          <p className="text-indigo-900 text-center font-medium text-lg leading-relaxed">
            {back}
          </p>
        </div>
      </motion.div>
    </div>
  );
};
