import React from 'react';
import { Check, X } from 'lucide-react';
import { cn } from '../lib/utils';

interface QuizProps {
  questions: Array<{ question: string; options: string[]; answer: string }>;
  onComplete: (score: number) => void;
}

export const Quiz: React.FC<QuizProps> = ({ questions, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = React.useState(0);
  const [selectedOption, setSelectedOption] = React.useState<string | null>(null);
  const [score, setScore] = React.useState(0);
  const [showResult, setShowResult] = React.useState(false);

  const handleOptionSelect = (option: string) => {
    if (selectedOption) return;
    setSelectedOption(option);
    if (option === questions[currentQuestion].answer) {
      setScore(s => s + 20); // 20 points per question
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(c => c + 1);
      setSelectedOption(null);
    } else {
      setShowResult(true);
      onComplete(score);
    }
  };

  const q = questions[currentQuestion];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center text-sm font-medium text-gray-500">
        <span>Question {currentQuestion + 1} of {questions.length}</span>
        <span>Points: {score}</span>
      </div>

      <h3 className="text-xl font-semibold text-gray-900 leading-tight">
        {q.question}
      </h3>

      <div className="grid gap-3">
        {q.options.map((option) => {
          const isSelected = selectedOption === option;
          const isCorrect = option === q.answer;
          const isWrong = isSelected && !isCorrect;

          return (
            <button
              key={option}
              onClick={() => handleOptionSelect(option)}
              disabled={!!selectedOption}
              className={cn(
                "group relative w-full p-4 text-left rounded-xl border-2 transition-all duration-200",
                !selectedOption && "border-gray-100 hover:border-indigo-500 hover:bg-indigo-50/50",
                selectedOption && isCorrect && "border-green-500 bg-green-50",
                selectedOption && isWrong && "border-red-500 bg-red-50",
                selectedOption && !isCorrect && !isSelected && "border-gray-100 opacity-50"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="text-gray-700 font-medium">{option}</span>
                {selectedOption && isCorrect && <Check className="w-5 h-5 text-green-600" />}
                {selectedOption && isWrong && <X className="w-5 h-5 text-red-600" />}
              </div>
            </button>
          );
        })}
      </div>

      {selectedOption && (
        <button
          onClick={nextQuestion}
          className="w-full py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors shadow-sm"
        >
          {currentQuestion === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
        </button>
      )}
    </div>
  );
};
