import React from 'react';
import { Upload, FileText, Loader2, Search, BookOpen, Brain, Trophy, History, User, Check, LogOut, Calendar, Award, Star, Play, Music, Sparkles, Shield, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import pdfToText from 'react-pdftotext';
import { generateStudyMaterial, type StudyData } from './services/geminiService';
import { Flashcard } from './components/Flashcard';
import { Quiz } from './components/Quiz';
import { Auth } from './components/Auth';
import { StudyPlanner } from './components/StudyPlanner';
import { ActivityGraph } from './components/ActivityGraph';
import { cn } from './lib/utils';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut, type User as FirebaseUser } from 'firebase/auth';
import { doc, onSnapshot, setDoc, addDoc, collection, serverTimestamp, getDoc, updateDoc } from 'firebase/firestore';

// Types for app state
interface AppState {
  view: 'dashboard' | 'study' | 'planner' | 'profile' | 'history' | 'auth';
  firebaseUser: FirebaseUser | null;
  userData: {
    name: string;
    progress: number;
    completedQuizzes: number;
    accuracy: number;
    badges: string[];
    certifications?: Array<{ id: string; courseName: string; dateAwarded: string }>;
  };
  studyData: StudyData | null;
  loading: boolean;
  loadingMessage: string;
  error: string | null;
  history: Array<{ topic: string; date: any; score: number; id?: string }>;
  dailyActivity?: Array<{ date: string; hours: number }>;
}

export default function App() {
  const loadingMessages = [
    "Analyzing your study material...",
    "Extracting key concepts with AI...",
    "Generating practice quizzes...",
    "Setting up your anime ambiance...",
    "Finalizing your personalized masterclass..."
  ];

  const [state, setState] = React.useState<AppState>({
    view: 'auth',
    firebaseUser: null,
    userData: {
      name: 'Learner',
      progress: 0,
      completedQuizzes: 0,
      accuracy: 0,
      badges: []
    },
    studyData: null,
    loading: false,
    loadingMessage: loadingMessages[0],
    error: null,
    history: []
  });

  const [messageIndex, setMessageIndex] = React.useState(0);

  // Cycle loading messages
  React.useEffect(() => {
    let interval: any;
    if (state.loading) {
      interval = setInterval(() => {
        setMessageIndex((prev) => (prev + 1) % loadingMessages.length);
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [state.loading]);

  React.useEffect(() => {
    if (state.loading) {
      setState(p => ({ ...p, loadingMessage: loadingMessages[messageIndex] }));
    }
  }, [messageIndex, state.loading]);

  const [searchQuery, setSearchQuery] = React.useState('');

  const [courses, setCourses] = React.useState<any[]>([]);

  // Auth State Observer
  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setState(prev => ({ ...prev, firebaseUser: user, view: 'dashboard' }));
      } else {
        setState(prev => ({ ...prev, firebaseUser: null, view: 'auth' }));
      }
    });
    return () => unsubscribe();
  }, []);

  // Sync User Data and History
  React.useEffect(() => {
    if (!state.firebaseUser) return;

    // Listen to User Profile
    const unsubUser = onSnapshot(doc(db, 'users', state.firebaseUser.uid), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setState(prev => ({
          ...prev,
          userData: {
            name: data.name || 'Learner',
            progress: data.progress || 0,
            completedQuizzes: data.completedQuizzes || 0,
            accuracy: data.accuracy || 0,
            badges: data.badges || []
          }
        }));
      }
    });

    // Listen to History
    const unsubHistory = onSnapshot(collection(db, 'users', state.firebaseUser.uid, 'sessions'), (snap) => {
      const historyItems = snap.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          topic: data.topic,
          date: data.date?.toDate?.()?.toLocaleDateString() || 'Recently',
          score: data.score || 0
        };
      }).sort((a, b) => b.id.localeCompare(a.id)); // Simple sorting
      
      setState(prev => ({ ...prev, history: historyItems }));
    });

    // Listen to Courses
    const unsubCourses = onSnapshot(collection(db, 'users', state.firebaseUser.uid, 'courses'), (snap) => {
      setCourses(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => {
      unsubUser();
      unsubHistory();
      unsubCourses();
    };
  }, [state.firebaseUser]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !state.firebaseUser) return;

    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      const text = await pdfToText(file);
      const studyData = await generateStudyMaterial(text);
      
      // Save session to Firestore
      await addDoc(collection(db, 'users', state.firebaseUser.uid, 'sessions'), {
        uid: state.firebaseUser.uid,
        topic: file.name,
        date: serverTimestamp(),
        score: 0,
        summary: studyData.summary,
        keyPoints: studyData.keyPoints,
        // We'll store simple versions of these for history
        mcqsCount: studyData.quizzes.mcqs.length
      });

      setState(prev => ({ 
        ...prev, 
        studyData, 
        loading: false, 
        view: 'study'
      }));
    } catch (err) {
      console.error(err);
      setState(prev => ({ ...prev, loading: false, error: 'Failed to process PDF. Please try again.' }));
    }
  };

  const handleQuizComplete = async (score: number) => {
    if (!state.firebaseUser) return;

    const userRef = doc(db, 'users', state.firebaseUser.uid);
    const newQuizzes = state.userData.completedQuizzes + 1;
    const newAccuracy = state.userData.accuracy === 0 ? score : Math.round((state.userData.accuracy + score) / 2);
    const newProgress = Math.min(100, state.userData.progress + 5);

    await updateDoc(userRef, {
      completedQuizzes: newQuizzes,
      accuracy: newAccuracy,
      progress: newProgress
    });
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  const renderNav = () => (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setState(p => ({ ...p, view: 'dashboard' }))}>
          <div className="p-2 bg-indigo-600 rounded-lg">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight">StudySmart AI</span>
        </div>
        
        {state.firebaseUser && (
          <div className="hidden md:flex items-center gap-6">
            <button 
              onClick={() => setState(p => ({ ...p, view: 'dashboard' }))}
              className={cn("text-sm font-medium transition-colors", state.view === 'dashboard' ? "text-indigo-600" : "text-slate-600 hover:text-indigo-600")}
            >
              Dashboard
            </button>
            <button 
              onClick={() => setState(p => ({ ...p, view: 'planner' }))}
              className={cn("text-sm font-medium transition-colors", state.view === 'planner' ? "text-indigo-600" : "text-slate-600 hover:text-indigo-600")}
            >
              Study Plan
            </button>
            <button 
              onClick={() => setState(p => ({ ...p, view: 'history' }))}
              className={cn("text-sm font-medium transition-colors", state.view === 'history' ? "text-indigo-600" : "text-slate-600 hover:text-indigo-600")}
            >
              History
            </button>
          </div>
        )}

        <div className="flex items-center gap-4">
          {state.firebaseUser && (
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search topics..." 
                className="pl-9 pr-4 py-2 bg-slate-100 border-none rounded-full text-sm focus:ring-2 focus:ring-indigo-500 w-48 transition-all"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          )}
          {state.firebaseUser ? (
            <button 
              onClick={handleLogout}
              className="p-2 hover:bg-rose-50 rounded-full transition-colors group"
              title="Logout"
            >
              <LogOut className="w-5 h-5 text-slate-600 group-hover:text-rose-600" />
            </button>
          ) : (
            <button 
              onClick={() => setState(p => ({ ...p, view: 'auth' }))}
              className="p-2 hover:bg-slate-100 rounded-full transition-colors"
            >
              <User className="w-5 h-5 text-slate-600" />
            </button>
          )}
        </div>
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {renderNav()}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          {state.view === 'auth' ? (
            <motion.div 
              key="auth"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="py-12"
            >
              <Auth onAuthSuccess={(user) => setState(p => ({ ...p, firebaseUser: user, view: 'dashboard' }))} />
            </motion.div>
          ) : state.loading ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-20"
            >
              <div className="relative mb-8">
                <Loader2 className="w-16 h-16 text-indigo-600 animate-spin" />
                <Brain className="w-8 h-8 text-indigo-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
              </div>
              <AnimatePresence mode="wait">
                <motion.p 
                  key={state.loadingMessage}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-lg text-slate-600 font-bold tracking-tight"
                >
                  {state.loadingMessage}
                </motion.p>
              </AnimatePresence>
              <div className="mt-8 flex gap-2">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    animate={{ scale: [1, 1.5, 1], opacity: [0.3, 1, 0.3] }}
                    transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.2 }}
                    className="w-2 h-2 bg-indigo-600 rounded-full"
                  />
                ))}
              </div>
            </motion.div>
          ) : state.view === 'dashboard' ? (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="bg-indigo-600 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden shadow-xl shadow-indigo-200">
                <div className="relative z-10 max-w-2xl">
                  <h1 className="text-4xl md:text-5xl font-bold leading-tight">Master Any Topic, {state.userData.name.split(' ')[0]}</h1>
                  <p className="mt-4 text-indigo-100 text-lg">Upload your PDF and transform it into a personalized learning journey with summaries, quizzes, and flashcards.</p>
                  
                  <div className="mt-8">
                    <label className="inline-flex items-center gap-3 bg-white text-indigo-600 px-8 py-4 rounded-2xl font-bold cursor-pointer hover:bg-indigo-50 transition-all shadow-lg active:scale-95">
                      <Upload className="w-5 h-5" />
                      <span>Upload PDF to Start</span>
                      <input type="file" className="hidden" accept=".pdf" onChange={handleFileUpload} />
                    </label>
                  </div>
                </div>
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/20 rounded-full -translate-y-1/2 translate-x-1/2" />
                <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-indigo-700/20 rounded-full translate-y-1/2" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm flex items-center gap-4 group hover:border-indigo-200 transition-all">
                  <div className="p-4 bg-indigo-50 rounded-2xl group-hover:bg-indigo-600 transition-colors">
                    <Trophy className="w-6 h-6 text-indigo-600 group-hover:text-white" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Learning Progress</p>
                    <p className="text-3xl font-black font-mono tracking-tighter">{state.userData.progress}%</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm flex items-center gap-4 group hover:border-emerald-200 transition-all">
                  <div className="p-4 bg-emerald-50 rounded-2xl group-hover:bg-emerald-600 transition-colors">
                    <Check className="w-6 h-6 text-emerald-600 group-hover:text-white" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Quizzes Completed</p>
                    <p className="text-3xl font-black font-mono tracking-tighter">{state.userData.completedQuizzes}</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm flex items-center gap-4 group hover:border-rose-200 transition-all">
                  <div className="p-4 bg-rose-50 rounded-2xl group-hover:bg-rose-600 transition-colors">
                    <History className="w-6 h-6 text-rose-600 group-hover:text-white" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Accuracy Rate</p>
                    <p className="text-3xl font-black font-mono tracking-tighter">{state.userData.accuracy}%</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <h2 className="text-xl font-bold">Study Activity</h2>
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Last 7 Days</span>
                    </div>
                    <ActivityGraph userId={state.firebaseUser!.uid} />
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-bold">Active Courses</h2>
                      <button className="text-sm font-semibold text-indigo-600 hover:text-indigo-700" onClick={() => setState(p => ({ ...p, view: 'planner' }))}>View Plan</button>
                    </div>
                    {courses.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {courses.slice(0, 4).map(course => (
                          <div key={course.id} className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex flex-col justify-between">
                            <h3 className="font-bold text-sm mb-1 truncate">{course.name}</h3>
                            <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold mb-2">
                              <span>LEVEL {course.level || 1}</span>
                              <span className="text-indigo-600">{course.hoursStudied || 0}H</span>
                            </div>
                            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${(course.totalPoints % 100)}%` }}
                                className="bg-indigo-600 h-full" 
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 bg-slate-50 border-2 border-dashed border-slate-100 rounded-2xl">
                        <BookOpen className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                        <p className="text-sm text-slate-400">No courses started yet.</p>
                        <button 
                          className="mt-2 text-xs font-bold text-indigo-600 hover:underline"
                          onClick={() => setState(p => ({ ...p, view: 'planner' }))}
                        >
                          Pick a suggested subject
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="bg-white rounded-[2rem] border border-slate-200 p-8 shadow-sm overflow-hidden relative">
                    <div className="flex items-center justify-between mb-8">
                      <div className="space-y-1">
                        <h2 className="text-xl font-bold tracking-tight">Activity Stream</h2>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                           <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                           Real-time data engine
                        </p>
                      </div>
                      <Shield className="w-5 h-5 text-slate-200" />
                    </div>

                    <div className="space-y-2 relative">
                      {/* Technical lines */}
                      <div className="absolute left-[23px] top-4 bottom-4 w-px bg-slate-100 z-0" />

                      {state.userData.badges.slice(0, 3).map((badge, i) => (
                        <div key={i} className="group relative z-10 flex items-start gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-all border border-transparent hover:border-slate-100">
                          <div className="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center border border-amber-100 group-hover:bg-amber-500 transition-colors">
                            <Award className="w-5 h-5 text-amber-600 group-hover:text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-0.5">
                               <p className="text-sm font-black text-slate-900 italic serif">CREDENTIAL_EARNED</p>
                               <span className="text-[9px] font-mono text-slate-400">0.4s ago</span>
                            </div>
                            <p className="text-xs font-bold text-slate-600 truncate uppercase tracking-tight">"{badge}"</p>
                          </div>
                        </div>
                      ))}

                      {state.history.slice(0, 3).map((item, i) => (
                        <div key={i} className="group relative z-10 flex items-start gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-all border border-transparent hover:border-slate-100">
                          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center border border-indigo-100 group-hover:bg-indigo-600 transition-colors">
                            <Brain className="w-5 h-5 text-indigo-600 group-hover:text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-0.5">
                               <p className="text-sm font-black text-slate-900 italic serif">SESSION_LOGGED</p>
                               <span className="text-[9px] font-mono text-slate-400">SYNCED</span>
                            </div>
                            <p className="text-xs font-bold text-slate-600 truncate uppercase tracking-tight">{item.topic.toUpperCase()}</p>
                          </div>
                        </div>
                      ))}

                      {state.userData.badges.length === 0 && state.history.length === 0 && (
                        <div className="py-12 text-center space-y-3">
                           <ShieldAlert className="w-8 h-8 text-slate-200 mx-auto" />
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Awaiting system signals...</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-bold flex items-center gap-2">
                        <History className="w-5 h-5 text-indigo-600" />
                        Recent Study
                      </h2>
                      <button className="text-xs font-bold text-indigo-600 hover:underline" onClick={() => setState(p => ({ ...p, view: 'history' }))}>
                        View All
                      </button>
                    </div>
                    {state.history.length > 0 ? (
                      <div className="space-y-4">
                        {state.history.slice(0, 3).map((item, idx) => (
                          <div key={item.id || idx} className="flex items-center justify-between p-4 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                            <div className="flex items-center gap-4">
                              <div className="p-2 bg-slate-100 rounded-lg">
                                <FileText className="w-5 h-5 text-slate-600" />
                              </div>
                              <div>
                                <p className="font-semibold">{item.topic}</p>
                                <p className="text-xs text-slate-400">{item.date}</p>
                              </div>
                            </div>
                            <span className="text-sm font-bold text-indigo-600">Studied</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 text-slate-400">
                        <p>No activity yet. Upload a PDF to get started!</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="lg:col-span-1 space-y-8">
                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <Award className="w-5 h-5 text-amber-500" />
                      Milestones
                    </h2>
                    <div className="space-y-4">
                      {state.userData.badges.length > 0 ? (
                        state.userData.badges.slice(0, 3).map((badge, i) => (
                          <div key={i} className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
                            <div className="p-2 bg-amber-100 rounded-lg">
                              <Star className="w-4 h-4 text-amber-600 fill-amber-600" />
                            </div>
                            <div>
                              <p className="text-sm font-bold text-slate-900">Earned: {badge}</p>
                              <p className="text-[10px] text-slate-400 font-medium">Achievement Locked in</p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-6">
                            <Trophy className="w-8 h-8 text-slate-200 mx-auto mb-2" />
                            <p className="text-xs text-slate-400">Unlock badges by completing courses!</p>
                        </div>
                      )}
                      
                      <div className="pt-4 border-t border-slate-100">
                        <div className="flex items-center justify-between text-xs mb-2">
                          <span className="font-bold text-slate-400">Overall Level</span>
                          <span className="text-indigo-600 font-black">LVL {Math.floor(state.userData.progress / 100) + 1}</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div 
                            className="bg-indigo-600 h-full transition-all duration-1000" 
                            style={{ width: `${state.userData.progress % 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-900 rounded-2xl p-6 text-white text-center">
                    <Brain className="w-10 h-10 text-indigo-400 mx-auto mb-4" />
                    <h3 className="font-bold text-lg mb-2">Want a new quiz?</h3>
                    <p className="text-slate-400 text-sm mb-6">Upload any textbook or notes and let AI test your knowledge instantly.</p>
                    <label className="block w-full bg-indigo-600 text-white py-3 rounded-xl font-bold cursor-pointer hover:bg-indigo-700 transition-all">
                      Start Quiz
                      <input type="file" className="hidden" accept=".pdf" onChange={handleFileUpload} />
                    </label>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : state.view === 'planner' && state.firebaseUser ? (
            <motion.div 
              key="planner"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <StudyPlanner userId={state.firebaseUser.uid} />
            </motion.div>
          ) : state.view === 'study' && state.studyData ? (
            <motion.div 
              key="study" 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 lg:grid-cols-4 gap-8"
            >
              {/* Sidebar Tabs */}
              <div className="lg:col-span-1 space-y-2">
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-1">
                  {[
                    { id: 'summary', label: 'Summary', icon: FileText },
                    { id: 'points', label: 'Key Points', icon: BookOpen },
                    { id: 'quiz', label: 'Practice Quiz', icon: Brain },
                    { id: 'flashcards', label: 'Flashcards', icon: History },
                    { id: 'videos', label: 'Ambiance', icon: Play },
                    { id: 'gamification', label: 'Achievements', icon: Trophy },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => document.getElementById(tab.id)?.scrollIntoView({ behavior: 'smooth' })}
                      className="w-full flex items-center gap-3 p-3 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 transition-all text-left"
                    >
                      <tab.icon className="w-4 h-4" />
                      {tab.label}
                    </button>
                  ))}
                </div>
                
                {state.studyData.searchExamples && (
                  <div className="bg-indigo-50 rounded-2xl p-6 border border-indigo-100">
                    <p className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-3">Topic Search Tips</p>
                    <div className="space-y-2">
                      {state.studyData.searchExamples.map((query, i) => (
                        <button key={i} className="text-xs text-indigo-800 hover:underline text-left block">
                          "{query}"
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Content Area */}
              <div className="lg:col-span-3 space-y-12">
                {/* Summary Section */}
                <section id="summary" className="scroll-mt-24 bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                  <h2 className="text-2xl font-bold flex items-center gap-2 mb-6">
                    <FileText className="w-6 h-6 text-indigo-600" />
                    Summary
                  </h2>
                  <p className="text-slate-700 leading-relaxed text-lg whitespace-pre-wrap">
                    {state.studyData.summary}
                  </p>
                </section>

                {/* Key Points */}
                <section id="points" className="scroll-mt-24 bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                  <h2 className="text-2xl font-bold flex items-center gap-2 mb-6">
                    <BookOpen className="w-6 h-6 text-emerald-600" />
                    Key Concepts
                  </h2>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {state.studyData.keyPoints.map((point, i) => (
                      <li key={i} className="flex gap-3 p-4 bg-slate-50 rounded-2xl text-slate-700 font-medium">
                        <span className="flex-shrink-0 w-6 h-6 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center text-xs font-bold">{i + 1}</span>
                        {point}
                      </li>
                    ))}
                  </ul>
                </section>

                {/* Flashcards */}
                <section id="flashcards" className="scroll-mt-24 space-y-6">
                  <h2 className="text-2xl font-bold flex items-center gap-2 px-2">
                    <History className="w-6 h-6 text-amber-600" />
                    Flashcards
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {state.studyData.flashcards.map((card, i) => (
                      <Flashcard key={i} front={card.front} back={card.back} />
                    ))}
                  </div>
                </section>

                <section id="videos" className="scroll-mt-24">
                  <div className="relative rounded-[3rem] overflow-hidden bg-slate-950 text-white min-h-[500px] flex flex-col justify-end p-8 md:p-16 border border-white/10 group">
                    {/* Atmospheric background */}
                    <div className="absolute inset-0 z-0">
                       <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent z-10" />
                       <div className="absolute inset-0 opacity-40 group-hover:opacity-60 transition-opacity duration-1000">
                          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/30 rounded-full blur-[100px] animate-pulse" />
                          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-[100px] animate-pulse delay-700" />
                       </div>
                    </div>

                    <div className="relative z-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                      <div className="space-y-8">
                        <div className="inline-flex items-center gap-3 px-4 py-2 bg-white/10 backdrop-blur-md rounded-full border border-white/20">
                          <Music className="w-4 h-4 text-indigo-400" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200">Atmospheric Study Flow</span>
                        </div>
                        
                        <div className="space-y-4">
                          <h2 className="text-5xl md:text-7xl font-black italic serif leading-[0.9] tracking-tight">
                            {state.studyData.animeAmbiance.theme}
                          </h2>
                          <p className="text-slate-400 text-lg leading-relaxed max-w-md font-medium">
                            {state.studyData.animeAmbiance.videoDescription}
                          </p>
                        </div>

                        <div className="flex flex-wrap gap-4">
                          <a 
                            href={`https://www.youtube.com/results?search_query=${encodeURIComponent(state.studyData.animeAmbiance.youtubeKeyword)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-white text-slate-950 px-8 py-4 rounded-2xl font-black text-sm flex items-center gap-3 hover:scale-105 transition-all shadow-xl shadow-white/10"
                          >
                            <Play className="w-5 h-5 fill-current" />
                            Launch Environment
                          </a>
                          <div className="px-6 py-4 rounded-2xl border border-white/20 backdrop-blur-md text-xs font-bold font-mono flex items-center gap-2">
                             <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                             CHANNEL: LOFI GIRL
                          </div>
                        </div>
                      </div>

                      <div className="aspect-video bg-black/40 backdrop-blur-xl rounded-[2rem] overflow-hidden border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] transform lg:rotate-2 group-hover:rotate-0 transition-transform duration-700">
                        <iframe 
                          src={`https://www.youtube.com/embed?listType=search&list=${encodeURI(state.studyData.animeAmbiance.youtubeKeyword)}`}
                          className="w-full h-full opacity-80 group-hover:opacity-100 transition-opacity"
                          title="Study Ambiance"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      </div>
                    </div>
                  </div>
                </section>

                {/* Quiz Section */}
                <section id="quiz" className="scroll-mt-24 bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                  <h2 className="text-2xl font-bold flex items-center gap-2 mb-8">
                    <Brain className="w-6 h-6 text-indigo-600" />
                    Knowledge Test
                  </h2>
                  <div className="max-w-2xl mx-auto">
                    <Quiz questions={state.studyData.quizzes.mcqs} onComplete={handleQuizComplete} />
                  </div>

                  {/* Self-Assessment Questions */}
                  <div className="mt-12 pt-12 border-t border-slate-100 space-y-8">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <Check className="w-5 h-5 text-emerald-500" />
                        Short Answer Prep
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {state.studyData.quizzes.shortQuestions.map((q, i) => (
                          <div key={i} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-sm text-slate-700 font-medium">
                            {q}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-indigo-500" />
                        Deep Dive Discussion
                      </h3>
                      <div className="space-y-3">
                        {state.studyData.quizzes.longQuestions.map((q, i) => (
                          <div key={i} className="p-6 bg-indigo-50/30 rounded-2xl border border-indigo-100 text-sm text-slate-800 font-bold leading-relaxed">
                            {q}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </section>

                {/* Gamification */}
                <section id="gamification" className="scroll-mt-24 space-y-6">
                  <div className="bg-amber-400 rounded-3xl p-8 text-amber-950 relative overflow-hidden">
                    <div className="absolute -bottom-8 -right-8 opacity-20 rotate-12">
                      <Trophy className="w-64 h-64" />
                    </div>
                    <div className="relative z-10">
                      <div className="flex items-center gap-2 mb-4">
                        <Trophy className="w-6 h-6" />
                        <h2 className="text-2xl font-bold italic serif">Mastery Achieved</h2>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                          <p className="text-[10px] uppercase font-black tracking-widest opacity-60 mb-3">Daily Inspiration</p>
                          <blockquote className="text-xl font-black italic serif leading-tight mb-6">
                            "{state.studyData.gamification.studyMantra}"
                          </blockquote>
                          <div className="space-y-2">
                            <p className="text-[10px] uppercase font-black tracking-widest opacity-60">Status Recommendation</p>
                            <div className="inline-block px-3 py-1 bg-amber-950 text-white rounded-lg text-xs font-bold font-mono">
                              TARGET: {state.studyData.gamification.suggestedLevel}
                            </div>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <p className="text-[10px] uppercase font-black tracking-widest opacity-60">Potential Badges</p>
                          <div className="flex flex-wrap gap-2">
                            {state.studyData.gamification.suggestedBadges.map((badge, i) => (
                              <div key={i} className="bg-white/80 backdrop-blur-sm px-4 py-2 rounded-xl text-xs font-bold border border-amber-500/20">
                                {badge}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="fallback"
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              {state.error ? (
                <div className="bg-rose-50 border border-rose-100 text-rose-600 p-4 rounded-xl max-w-md mx-auto">
                  {state.error}
                  <button onClick={() => setState(p => ({ ...p, view: 'dashboard' }))} className="block w-full mt-4 font-bold underline">Go Back</button>
                </div>
              ) : (
                <div className="space-y-4">
                  <User className="w-16 h-16 text-slate-200 mx-auto" />
                  <p className="text-slate-500 font-medium">This section ({state.view}) is under development.</p>
                  <button onClick={() => setState(p => ({ ...p, view: 'dashboard' }))} className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold">Return to Dashboard</button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Persistence Note - Footer section */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-t border-slate-200 mt-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-end">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Brain className="w-6 h-6 text-indigo-600" />
              <span className="font-bold text-lg">StudySmart AI</span>
            </div>
            <p className="text-slate-500 text-sm max-w-sm">
              Empowering students through intelligent study material generation and gamified learning experiences.
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-slate-400 font-medium tracking-widest uppercase mb-4">Cloud Powered</p>
            <p className="text-sm text-slate-500">Your profile and history are synced with Firestore.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
