import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface StudyConcept {
  front: string;
  back: string;
}

export interface QuizQuestion {
  question: string;
  options: {a: string, b: string, c: string, d: string};
  answer: string;
}

export interface VisualScene {
  title: string;
  description: string;
  animationHint: string;
  emoji: string;
}

export interface ConceptNode {
  id: string;
  label: string;
  type: 'core' | 'supporting' | 'detail';
}

export interface ConceptLink {
  source: string;
  target: string;
  relationship: string;
}

export interface SimulationStep {
  id: number;
  scenario: string;
  options: {
    label: string;
    description: string;
    outcome: string;
    isCorrect: boolean;
  }[];
}

export interface StudyData {
  verification: {
    subject: string;
    trustScore: number;
    logicalCheck: string;
    sourceDNA: string[];
    illustrativeQuote: string;
  };
  summary: string;
  detailedAnalysis: string;
  keyPoints: string[];
  mcqs: QuizQuestion[];
  shortQuestions: string[];
  longQuestions: string[];
  flashcards: StudyConcept[];
  gamification: {
    suggestedBadges: string[];
    levels: string[];
  };
  searchExamples: string[];
  visualSummary: VisualScene[];
  conceptMap: {
    nodes: ConceptNode[];
    links: ConceptLink[];
  };
  simulation: {
    title: string;
    description: string;
    steps: SimulationStep[];
  };
}

export async function generateStudyAssistantContent(pdfText: string): Promise<StudyData> {
  const prompt = `
You are an advanced AI study assistant. Based on the following extracted text from a PDF, generate a structured, interactive, and deep analytical learning experience.

CONTENT:
${pdfText.substring(0, 30000)}

TASK:
1. LOGICAL VERIFICATION: 
   - Define the primary subject and target audience.
   - Provide a "Logical Check" sentence confirming consistency.
   - IDENTIFY SOURCE DNA: Extract 5 highly specific, technical, or unique keywords that ONLY appear in this document.
   - ILLUSTRATIVE QUOTE: Select one verbatim, impactful sentence from the text as "Visual Proof" of grounding.
2. SUMMARY: Provide a high-level, student-friendly "Executive Summary" (max 150 words).
3. DETAILED ANALYSIS: Provide a comprehensive, structured deep-dive into the material (300-500 words). Use clear headings or sections. Address the logical framework, major arguments, and nuances.
4. KEY POINTS: Extract the most important concepts/definitions/formulas with high precision.
5. PRACTICE QUIZ: 5 high-quality MCQs that test conceptual understanding, 3 Short questions, and 2 Long questions.
6. FLASHCARDS: At least 10 flashcards.
7. GAMIFICATION: Suggested levels and 3 specific badges.
8. SEARCH: 3 optimized example queries.
9. VISUAL SUMMARY (Animated Video): 5 "Cinematic" scenes. Each MUST include a Title, a metaphorical Description, a detailed Animation Hint, and a single Emoji that represents the scene's core concept. The scenes should follow a narrative arc: (1) Intro/Hook, (2) Deep Dive, (3) Complexity/Conflict, (4) Resolution, (5) Synthesis.
10. CONCEPT MAP (Visualization): Identify 8-10 key concepts as nodes and define relationships.
11. INTERACTIVE SIMULATION (Simulation): Create a 3-step decision-making simulation.

Return the data STRICTLY as JSON. Ensure the analysis is rigorously grounded in the provided text.
`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          verification: {
            type: Type.OBJECT,
            properties: {
              subject: { type: Type.STRING },
              trustScore: { type: Type.NUMBER },
              logicalCheck: { type: Type.STRING },
              sourceDNA: { type: Type.ARRAY, items: { type: Type.STRING } },
              illustrativeQuote: { type: Type.STRING }
            },
            required: ["subject", "trustScore", "logicalCheck", "sourceDNA", "illustrativeQuote"]
          },
          summary: { type: Type.STRING },
          detailedAnalysis: { type: Type.STRING },
          keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
          mcqs: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: {
                  type: Type.OBJECT,
                  properties: { a: { type: Type.STRING }, b: { type: Type.STRING }, c: { type: Type.STRING }, d: { type: Type.STRING } },
                  required: ["a", "b", "c", "d"]
                },
                answer: { type: Type.STRING }
              },
              required: ["question", "options", "answer"]
            }
          },
          shortQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
          longQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
          flashcards: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: { front: { type: Type.STRING }, back: { type: Type.STRING } },
              required: ["front", "back"]
            }
          },
          gamification: {
            type: Type.OBJECT,
            properties: {
              suggestedBadges: { type: Type.ARRAY, items: { type: Type.STRING } },
              levels: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          },
          searchExamples: { type: Type.ARRAY, items: { type: Type.STRING } },
          visualSummary: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                animationHint: { type: Type.STRING },
                emoji: { type: Type.STRING }
              },
              required: ["title", "description", "animationHint", "emoji"]
            }
          },
          conceptMap: {
            type: Type.OBJECT,
            properties: {
              nodes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    label: { type: Type.STRING },
                    type: { type: Type.STRING, enum: ['core', 'supporting', 'detail'] }
                  },
                  required: ["id", "label", "type"]
                }
              },
              links: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    source: { type: Type.STRING },
                    target: { type: Type.STRING },
                    relationship: { type: Type.STRING }
                  },
                  required: ["source", "target", "relationship"]
                }
              }
            },
            required: ["nodes", "links"]
          },
          simulation: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              steps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.INTEGER },
                    scenario: { type: Type.STRING },
                    options: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          label: { type: Type.STRING },
                          description: { type: Type.STRING },
                          outcome: { type: Type.STRING },
                          isCorrect: { type: Type.BOOLEAN }
                        },
                        required: ["label", "description", "outcome", "isCorrect"]
                      }
                    }
                  },
                  required: ["id", "scenario", "options"]
                }
              }
            },
            required: ["title", "description", "steps"]
          }
        },
        required: ["verification", "summary", "detailedAnalysis", "keyPoints", "mcqs", "shortQuestions", "longQuestions", "flashcards", "gamification", "searchExamples", "visualSummary", "conceptMap", "simulation"]
      }
    }
  });

  return JSON.parse(response.text);
}
