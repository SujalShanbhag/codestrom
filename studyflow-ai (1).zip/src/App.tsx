import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, FileText, BookOpen, Brain, Trophy, Search, User, History, LogIn, CheckCircle2, LogOut, ChevronLeft, ChevronRight, RotateCcw, RefreshCcw, Calendar, Clock, Plus, Trash2, Video, Award, Download, Star } from 'lucide-react';
import { StudyData, generateStudyAssistantContent, VisualScene, SimulationStep, ConceptNode, ConceptLink } from './services/geminiService';
import Markdown from 'react-markdown';
import { extractTextFromPdf, PdfPage } from './lib/pdf';
import { cn } from './lib/utils';
import { auth, signInWithGoogle, signOut, db, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, where, orderBy, onSnapshot, addDoc, Timestamp, deleteDoc } from 'firebase/firestore';

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
}

export const AVAILABLE_BADGES: Badge[] = [
  { id: 'early_bird', name: 'Early Bird', description: 'Study before 8 AM', icon: '🌅', color: 'bg-orange-100 text-orange-600' },
  { id: 'quiz_master', name: 'Quiz Master', description: 'Score 100% on a quiz', icon: '🎯', color: 'bg-indigo-100 text-indigo-600' },
  { id: 'night_owl', name: 'Night Owl', description: 'Study after 10 PM', icon: '🦉', color: 'bg-purple-100 text-purple-600' },
  { id: 'streak_3', name: 'Hot Streak', description: 'Maintain a 3-day streak', icon: '🔥', color: 'bg-red-100 text-red-600' },
  { id: 'marathon', name: 'Study Marathon', description: 'Study for over 60 minutes in one session', icon: '🏃', color: 'bg-green-100 text-green-600' },
  { id: 'encyclopedia', name: 'Scholar', description: 'Analyze 5 different PDFs', icon: '📚', color: 'bg-blue-100 text-blue-600' },
];

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  level: number;
  xp: number;
  totalStudyMinutes: number;
  badges: string[];
  streak: number;
  lastActive: string;
}

export interface SessionRecord {
  id: string;
  title: string;
  type: 'summary' | 'quiz' | 'flashcards';
  score: string;
  status: string;
  durationMinutes?: number;
  timestamp: string;
}

export interface TimetableEntry {
  id: string;
  userId: string;
  day: string;
  startTime: string;
  endTime: string;
  subject: string;
}

export interface Certification {
  id: string;
  userId: string;
  title: string;
  score: number;
  timestamp: string;
  certificateId: string;
}

// --- Mock Components for now (will build properly) ---

const LoadingOverlay = () => {
  const [msgIdx, setMsgIdx] = useState(0);
  const messages = [
    "EXTRACTING DOCUMENT ARCHITECTURE...",
    "SYNTHESIZING CORE CONCEPTS...",
    "MAPPING LOGICAL RELATIONSHIPS...",
    "GENERATING SIMULATION SCENARIOS...",
    "FINALIZING ANALYTICAL CONTENT..."
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setMsgIdx(prev => (prev + 1) % messages.length);
    }, 2500);
    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="fixed inset-0 bg-slate-950/98 backdrop-blur-xl z-50 flex flex-col items-center justify-center p-12 text-center"
    >
      <div className="relative w-32 h-32 mb-16">
        <motion.div 
          animate={{ rotate: 360, borderTopColor: ['#6366F1', '#4F46E5', '#6366F1'] }} 
          transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
          className="w-full h-full border-2 border-white/5 rounded-full"
        />
        <div className="absolute inset-0 flex items-center justify-center text-5xl font-serif italic text-white/20">
           S.
        </div>
      </div>
      <motion.p 
        key={msgIdx}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 1.1 }}
        className="text-[10px] font-mono text-slate-500 tracking-[0.6em] uppercase max-w-md leading-loose mb-2"
      >
        System Status
      </motion.p>
      <motion.p 
        key={`msg-${msgIdx}`}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        className="text-xl font-bold text-white tracking-tight"
      >
        {messages[msgIdx]}
      </motion.p>
      <div className="w-12 h-[1px] bg-slate-800 my-8" />
      <div className="flex gap-1">
         {[0,1,2].map(i => (
           <motion.div 
             key={i}
             animate={{ opacity: [0.2, 1, 0.2] }}
             transition={{ repeat: Infinity, duration: 1, delay: i * 0.2 }}
             className="w-1 h-1 bg-primary rounded-full"
           />
         ))}
      </div>
    </motion.div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'upload' | 'study' | 'profile' | 'history' | 'schedule'>('upload');
  const [loading, setLoading] = useState(false);
  const [studyData, setStudyData] = useState<StudyData | null>(null);
  const [pdfText, setPdfText] = useState<string>('');
  const [pdfPages, setPdfPages] = useState<PdfPage[]>([]);
  const [currentFileName, setCurrentFileName] = useState<string>('');
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [timetable, setTimetable] = useState<TimetableEntry[]>([]);
  const [certifications, setCertifications] = useState<Certification[]>([]);
  const [studyStartTime, setStudyStartTime] = useState<number | null>(null);

  // Auth & Profile Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        // Fetch or Create Profile
        const profileRef = doc(db, 'users', u.uid);
        try {
          const snap = await getDoc(profileRef);
          if (snap.exists()) {
            setProfile(snap.data() as UserProfile);
          } else {
            const newProfile: UserProfile = {
              uid: u.uid,
              displayName: u.displayName || 'Scholar',
              email: u.email || '',
              level: 1,
              xp: 0,
              totalStudyMinutes: 0,
              badges: [],
              streak: 1,
              lastActive: new Date().toISOString(),
            };
            await setDoc(profileRef, newProfile);
            setProfile(newProfile);
          }
        } catch (e) {
          handleFirestoreError(e, OperationType.GET, 'users');
        }

        // Sessions Listener
        const q = query(collection(db, 'sessions'), where('userId', '==', u.uid), orderBy('timestamp', 'desc'));
        const unsubSessions = onSnapshot(q, (snap) => {
          const docs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as SessionRecord[];
          setSessions(docs);
        }, (e) => handleFirestoreError(e, OperationType.LIST, 'sessions'));

        // Timetable Listener
        const qt = query(collection(db, 'timetable'), where('userId', '==', u.uid));
        const unsubTimetable = onSnapshot(qt, (snap) => {
          const docs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as TimetableEntry[];
          setTimetable(docs);
        }, (e) => handleFirestoreError(e, OperationType.LIST, 'timetable'));

        // Certifications Listener
        const qc = query(collection(db, 'certifications'), where('userId', '==', u.uid), orderBy('timestamp', 'desc'));
        const unsubCertifications = onSnapshot(qc, (snap) => {
          const docs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Certification[];
          setCertifications(docs);
        }, (e) => handleFirestoreError(e, OperationType.LIST, 'certifications'));

        return () => {
          unsubSessions();
          unsubTimetable();
          unsubCertifications();
        };
      } else {
        setProfile(null);
        setSessions([]);
        setTimetable([]);
        setCertifications([]);
      }
    });
    return () => unsubscribe();
  }, []);

  // Timer logic
  useEffect(() => {
    if (activeTab === 'study' && studyData && !studyStartTime) {
      setStudyStartTime(Date.now());
    } else if (activeTab !== 'study' && studyStartTime) {
      // User left the study tab, calculate duration
      const durationMs = Date.now() - studyStartTime;
      const durationMins = Math.floor(durationMs / 60000);
      if (durationMins > 0) {
        // Record this automatically or add to last session?
        // For simplicity, let's just track total time in profile
        updateTotalStudyTime(durationMins);
      }
      setStudyStartTime(null);
    }
  }, [activeTab, studyData]);

  const updateTotalStudyTime = async (minutes: number) => {
    if (!user || !profile) return;
    const profileRef = doc(db, 'users', user.uid);
    const newTotal = (profile.totalStudyMinutes || 0) + minutes;
    await setDoc(profileRef, { totalStudyMinutes: newTotal }, { merge: true });
  };

  const saveSession = async (title: string, type: SessionRecord['type'], score: string = '-', status: string = 'Completed') => {
    if (!user) return;
    const duration = studyStartTime ? Math.floor((Date.now() - studyStartTime) / 60000) : 0;
    
    try {
      await addDoc(collection(db, 'sessions'), {
        userId: user.uid,
        title,
        type,
        score,
        status,
        durationMinutes: duration,
        timestamp: new Date().toISOString(),
      });
      
      // Update XP in profile
      if (profile) {
        const profileRef = doc(db, 'users', user.uid);
        const xpGain = score !== '-' ? parseInt(score) * 10 : 20;
        // Also add XP for duration? e.g. 5 XP per minute
        const durationXp = duration * 5;

        // Badge Logic
        const newBadges = [...(profile.badges || [])];
        const accuracy = score !== '-' ? (parseInt(score) / (studyData?.mcqs.length || 1)) * 100 : 0;
        
        if (accuracy === 100 && !newBadges.includes('quiz_master')) {
          newBadges.push('quiz_master');
        }
        if (duration >= 60 && !newBadges.includes('marathon')) {
          newBadges.push('marathon');
        }
        
        const hour = new Date().getHours();
        if (hour < 8 && !newBadges.includes('early_bird')) {
          newBadges.push('early_bird');
        }
        if (hour >= 22 && !newBadges.includes('night_owl')) {
          newBadges.push('night_owl');
        }

        await setDoc(profileRef, { 
          xp: profile.xp + xpGain + durationXp,
          totalStudyMinutes: (profile.totalStudyMinutes || 0) + duration,
          badges: newBadges
        }, { merge: true });

        // Certification Logic
        if (type === 'quiz' && accuracy >= 80) {
          const existingCert = certifications.find(c => c.title === title);
          if (!existingCert) {
            await addDoc(collection(db, 'certifications'), {
              userId: user.uid,
              title,
              score: accuracy,
              timestamp: new Date().toISOString(),
              certificateId: `CERT-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
            });
          }
        }
      }
      // Reset timer start for next activity if still in study tab
      setStudyStartTime(Date.now());
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'sessions');
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      setCurrentFileName(file.name);
      const { fullText, pages } = await extractTextFromPdf(file);
      setPdfText(fullText);
      setPdfPages(pages);
      const data = await generateStudyAssistantContent(fullText);
      setStudyData(data);
      setActiveTab('study');
    } catch (error) {
      console.error('Processing failed:', error);
      alert('Failed to process PDF. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg-base text-zinc-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {loading && <LoadingOverlay />}

      {/* Sidebar Navigation */}
      <aside className="fixed left-0 top-0 h-full w-[240px] border-r border-border-base bg-white flex flex-col py-8 px-6 gap-8 z-40">
        <div className="flex items-center gap-3 px-2 mb-4">
          <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center text-white font-serif italic text-xl shadow-2xl shadow-slate-200">
            S.
          </div>
          <span className="text-xl font-black text-slate-900 tracking-tighter">StudyFlow</span>
        </div>
        
        <nav className="flex-1 flex flex-col gap-2">
          <SidebarNavItem icon={Upload} label="Dashboard" active={activeTab === 'upload'} onClick={() => setActiveTab('upload')} />
          <SidebarNavItem icon={BookOpen} label="My Study" active={activeTab === 'study'} onClick={() => setActiveTab('study')} disabled={!studyData} />
          <SidebarNavItem icon={Calendar} label="Schedule" active={activeTab === 'schedule'} onClick={() => setActiveTab('schedule')} />
          <SidebarNavItem icon={History} label="History" active={activeTab === 'history'} onClick={() => setActiveTab('history')} />
          <SidebarNavItem icon={User} label="Profile" active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} />
        </nav>

        {user && profile && (
          <div className="mt-auto p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <h4 className="text-sm font-bold text-slate-800">{profile.displayName}</h4>
            <p className="text-[11px] text-slate-500 font-medium">Level {profile.level} • {profile.xp} XP</p>
            <div className="h-1.5 bg-slate-200 rounded-full mt-3 overflow-hidden">
              <div className="h-full bg-primary" style={{ width: '72%' }} />
            </div>
          </div>
        )}

        <button 
          onClick={user ? signOut : signInWithGoogle}
          className={cn(
            "p-3 rounded-xl transition-all flex items-center gap-3 font-semibold text-sm",
            user ? "text-red-500 hover:bg-red-50" : "text-slate-400 hover:text-primary hover:bg-slate-50"
          )}
        >
          {user ? (
            <><LogOut className="w-5 h-5" /> Sign Out</>
          ) : (
            <><LogIn className="w-5 h-5" /> Sign In</>
          )}
        </button>
      </aside>

      {/* Main Content Area */}
      <main className="pl-[240px] min-h-screen">
        <header className="h-20 border-b border-border-base flex items-center justify-between px-10 bg-white/80 backdrop-blur-md sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <div className="w-96 bg-slate-100 flex items-center gap-3 px-4 py-2.5 rounded-xl border border-transparent focus-within:border-primary/20 transition-all">
              <Search className="w-4 h-4 text-slate-400" />
              <span className="text-sm text-slate-400 font-medium">Search concepts...</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="bg-orange-50 text-orange-600 border border-orange-100 px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2">
              🔥 {profile?.streak || 0} Day Streak
            </div>
            <div className="w-px h-6 bg-slate-200" />
            <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
              <Trophy className="w-4 h-4 text-primary" />
              <span>{profile?.xp || 0} XP</span>
            </div>
          </div>
        </header>

        <div className="p-8 max-w-6xl mx-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'upload' && (
              <motion.div
                key="upload"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col items-center justify-center py-12"
              >
                <div className="text-center mb-16 space-y-4">
                  <h2 className="text-6xl md:text-8xl font-serif italic font-black text-slate-900 tracking-tighter leading-[0.85] mb-8">Deep Knowledge,<br/>Faster.</h2>
                  <div className="flex justify-center flex-wrap gap-4">
                     <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 bg-white px-4 py-1.5 rounded-full border border-slate-200 shadow-sm">AI Verified Analysis</span>
                     <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 bg-white px-4 py-1.5 rounded-full border border-slate-200 shadow-sm">Real-time Visualization</span>
                     <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 bg-white px-4 py-1.5 rounded-full border border-slate-200 shadow-sm">Interactive Simulation</span>
                  </div>
                </div>

                <label className="w-full max-w-2xl bg-white border-2 border-dashed border-slate-200 rounded-[48px] p-20 flex flex-col items-center justify-center gap-8 hover:border-primary hover:bg-slate-50 transition-all cursor-pointer group shadow-2xl shadow-slate-200/50 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  <div className="w-24 h-24 bg-slate-900 rounded-[32px] flex items-center justify-center text-white group-hover:scale-105 group-hover:-rotate-3 transition-all duration-500 shadow-2xl shadow-slate-900/20">
                    <Upload className="w-10 h-10" />
                  </div>
                  <div className="text-center space-y-3">
                    <p className="text-2xl font-black text-slate-800 tracking-tight">Select Document to Analyze</p>
                    <p className="text-sm text-slate-400 font-medium">Standard PDF format • Max 30,000 chars context</p>
                  </div>
                  <div className="px-6 py-2 bg-slate-100 rounded-full text-[10px] font-black tracking-[0.2em] uppercase text-slate-400 group-hover:bg-primary group-hover:text-white transition-colors">
                     Begin Synthesis
                  </div>
                  <input type="file" className="hidden" accept=".pdf" onChange={handleFileUpload} />
                </label>

                <div className="mt-20 grid grid-cols-2 gap-20 w-full max-w-4xl opacity-50">
                   <div className="flex gap-4">
                      <div className="w-1 h-12 bg-slate-200" />
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest mb-1">Processing</p>
                        <p className="text-xs text-slate-500 leading-relaxed italic">Neural extraction of document logical hierarchies and concept maps.</p>
                      </div>
                   </div>
                   <div className="flex gap-4">
                      <div className="w-1 h-12 bg-slate-200" />
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest mb-1">Visualization</p>
                        <p className="text-xs text-slate-500 leading-relaxed italic">High-fidelity cinematic generation of metaphorical conceptual models.</p>
                      </div>
                   </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'study' && studyData && (
              <StudyContent 
                data={studyData} 
                profile={profile} 
                pdfText={pdfText} 
                pages={pdfPages} 
                fileName={currentFileName}
                onFinished={(type, score, status) => saveSession('PDF Study Session', type, score, status)} 
              />
            )}

            {activeTab === 'profile' && profile && (
              <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-12 py-10">
                <div className="flex items-center gap-8">
                  <div className="w-24 h-24 bg-blue-600 rounded-3xl flex items-center justify-center text-3xl font-bold text-white shadow-xl shadow-blue-100">
                    {profile.displayName.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="space-y-1">
                    <h2 className="text-3xl font-bold">{profile.displayName}</h2>
                    <p className="text-zinc-500 font-mono text-sm uppercase tracking-widest">Scholar • Level {profile.level}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <StatCard label="Total XP" value={profile.xp.toLocaleString()} sub="Career Reward Points" />
                  <StatCard label="Study Time" value={`${Math.floor((profile.totalStudyMinutes || 0) / 60)}h ${ (profile.totalStudyMinutes || 0) % 60 }m`} sub="Total Invested" />
                  <StatCard label="Streak" value={`${profile.streak} Days`} sub="Daily Consistency" />
                  <StatCard label="Badges" value={profile.badges.length.toString()} sub="Earned Rewards" />
                </div>

                <div className="grid md:grid-cols-2 gap-12">
                   <div className="space-y-12">
                     <section className="space-y-6">
                        <h3 className="text-sm font-mono text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Achievement Collection</h3>
                        <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
                          {AVAILABLE_BADGES.map(badge => {
                            const isEarned = profile.badges?.includes(badge.id);
                            return (
                              <div 
                                key={badge.id} 
                                className={cn(
                                  "aspect-square rounded-[24px] border flex flex-col items-center justify-center gap-2 p-2 transition-all relative overflow-hidden group",
                                  isEarned 
                                    ? `${badge.color} border-transparent shadow-md scale-100` 
                                    : "bg-slate-50 border-slate-100 opacity-40 grayscale scale-95 hover:grayscale-0 hover:opacity-60"
                                )}
                              >
                                <span className="text-3xl filter drop-shadow-sm">{badge.icon}</span>
                                <span className="text-[9px] font-black uppercase tracking-tighter text-center">{badge.name}</span>
                                
                                {!isEarned && (
                                  <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/80 flex items-center justify-center p-3 opacity-0 group-hover:opacity-100 transition-all">
                                    <p className="text-[8px] text-white font-bold text-center leading-tight">{badge.description}</p>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                     </section>

                     <section className="space-y-6">
                        <h3 className="text-sm font-mono text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Professional Certifications</h3>
                        <div className="grid gap-4">
                          {certifications.map(cert => (
                            <CertificationCard key={cert.id} data={cert} />
                          ))}
                          {certifications.length === 0 && <p className="text-xs text-zinc-400 italic">Complete a quiz with 80%+ accuracy to earn certifications.</p>}
                        </div>
                     </section>
                   </div>

                   <section className="space-y-6">
                      <h3 className="text-sm font-mono text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Recent Activity</h3>
                      <div className="space-y-4">
                        {sessions.slice(0, 3).map(s => (
                          <ActivityItem key={s.id} label={s.title} sub={`${new Date(s.timestamp).toLocaleDateString()} • ${s.durationMinutes || 0}m`} />
                        ))}
                        {sessions.length === 0 && <p className="text-xs text-zinc-400 italic">No activity recorded.</p>}
                      </div>
                   </section>
                </div>
              </motion.div>
            )}

            {activeTab === 'schedule' && (
              <ScheduleView timetable={timetable} userId={user?.uid || ''} />
            )}

            {activeTab === 'history' && (
              <motion.div key="history" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-10 space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-3xl font-bold">Learning History</h2>
                  <div className="flex items-center gap-2 px-4 py-2 bg-zinc-100 rounded-xl text-xs font-mono text-zinc-600">
                    <History className="w-4 h-4" />
                    <span>{sessions.length} TOTAL SESSIONS</span>
                  </div>
                </div>

                <div className="grid gap-4">
                  {sessions.map(s => (
                    <HistoryCard key={s.id} title={s.title} date={new Date(s.timestamp).toLocaleDateString()} score={s.score} status={s.status} duration={s.durationMinutes} />
                  ))}
                  {sessions.length === 0 && (
                    <div className="py-20 text-center text-zinc-400 italic">Upload a PDF to start your learning journey.</div>
                  )}
                </div>
              </motion.div>
            )}
            
            {(activeTab === 'profile' || activeTab === 'history') && !user && (
              <div className="flex flex-col items-center justify-center py-24 gap-6">
                <LogIn className="w-12 h-12 text-zinc-200" />
                <div className="text-center space-y-2">
                  <h3 className="text-xl font-bold">Authentication Required</h3>
                  <p className="text-zinc-500">Sign in to track your progress and saved history.</p>
                </div>
                <button 
                  onClick={signInWithGoogle}
                  className="px-8 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors flex items-center gap-3"
                >
                  <LogIn className="w-5 h-5" />
                  Sign in with Google
                </button>
              </div>
            )}
          </AnimatePresence>
        </div>

      </main>
    </div>
  );
}

function StatCard({ label, value, sub }: { label: string, value: string, sub: string }) {
  return (
    <div className="bg-white p-6 rounded-[24px] border border-border-base shadow-sm flex flex-col gap-1 items-center text-center">
      <span className="text-3xl font-extrabold text-primary">{value}</span>
      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">{label}</span>
    </div>
  );
}

function ActivityItem({ label, sub, ...props }: { label: string, sub: string, [key: string]: any }) {
  return (
    <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100/50">
      <div className="flex flex-col">
        <span className="text-sm font-medium">{label}</span>
        <span className="text-[10px] text-zinc-400">{sub}</span>
      </div>
      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
    </div>
  );
}

function HistoryCard({ title, date, score, status, duration, ...props }: { title: string, date: string, score: string, status: string, duration?: number, [key: string]: any }) {
  return (
    <div className="p-6 bg-white border border-border-base rounded-[24px] shadow-sm flex items-center justify-between group hover:border-primary/30 transition-all">
      <div className="flex flex-col gap-1">
        <h4 className="font-bold text-slate-800">{title}</h4>
        <div className="flex items-center gap-3 text-xs text-slate-400 font-medium">
          <span>{date}</span>
          <span className="w-1.5 h-1.5 bg-slate-100 rounded-full" />
          <span>{duration ? `${duration}m` : 'Quick Read'}</span>
          <span className="w-1.5 h-1.5 bg-slate-100 rounded-full" />
          <span className={cn(
            status === 'Completed' ? "text-green-500" : "text-orange-500"
          )}>{status}</span>
        </div>
      </div>
      <div className="flex items-center gap-12">
        <div className="text-right">
           <p className="text-[10px] font-bold text-slate-400 mb-1 uppercase tracking-tighter">SCORE</p>
           <p className="text-xl font-black text-primary">{score}</p>
        </div>
        <button className="px-5 py-2.5 bg-indigo-50 text-primary group-hover:bg-primary group-hover:text-white rounded-xl text-xs font-bold transition-all shadow-sm">
          Continue
        </button>
      </div>
    </div>
  );
}

function SidebarNavItem({ icon: Icon, label, active, onClick, disabled }: { icon: any, label: string, active: boolean, onClick: () => void, disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "flex items-center gap-4 px-5 py-4 rounded-[20px] transition-all font-bold text-sm group relative",
        active 
          ? "bg-slate-900 text-white shadow-2xl shadow-slate-300 scale-[1.02]" 
          : "text-slate-400 hover:text-slate-900 hover:bg-slate-50",
        disabled && "opacity-30 cursor-not-allowed"
      )}
    >
      <Icon className={cn("w-5 h-5 transition-transform", active ? "scale-110" : "group-hover:scale-110")} />
      <span>{label}</span>
      {active && (
        <motion.div 
          layoutId="active-indicator"
          className="absolute -left-1 w-2 h-2 bg-primary rounded-full"
        />
      )}
    </button>
  );
}

// --- Final Components ---

function VisualSummaryView({ scenes, onComplete }: { scenes: VisualScene[], onComplete: () => void }) {
  const [currentScene, setCurrentScene] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const total = scenes.length;
  
  // 60 seconds total / 5 scenes = 12 seconds per scene
  const SCENE_DURATION = 12000; 

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            if (currentScene < total - 1) {
              setCurrentScene(prevScene => prevScene + 1);
              return 0;
            } else {
              setIsPlaying(false);
              onComplete();
              return 100;
            }
          }
          return prev + (100 / (SCENE_DURATION / 100)); // Update every 100ms
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentScene, total]);

  const scene = scenes[currentScene];

  return (
    <div className="max-w-4xl mx-auto py-12 space-y-8">
      <div className="flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center text-white animate-pulse">
            <Video className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-800 tracking-tight">Concept Visualization</h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">1-Minute Deep Dive</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-10 h-10 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-600 hover:text-primary transition-colors focus:outline-none"
          >
            {isPlaying ? <Clock className="w-5 h-5 animate-spin-slow" /> : <Star className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <div className="relative aspect-video bg-black rounded-[40px] overflow-hidden border-[8px] border-slate-900 shadow-2xl flex flex-col items-center justify-center p-12 text-center group">
        {/* Dynamic Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
           <motion.div 
             animate={{ 
               scale: [1, 1.2, 1],
               rotate: [0, 90, 180, 270, 360],
               x: [-20, 20, -20],
               y: [-20, 20, -20]
             }}
             transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
             className="absolute -inset-[100%] bg-gradient-to-tr from-blue-600 via-purple-500 to-indigo-800 opacity-40 blur-3xl"
           />
        </div>

        <AnimatePresence mode="wait">
          <motion.div 
            key={currentScene}
            initial={{ opacity: 0, y: 20, filter: 'blur(10px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -20, filter: 'blur(10px)' }}
            transition={{ duration: 0.8 }}
            className="space-y-8 max-w-2xl relative z-10"
          >
            <div className="bg-white/10 backdrop-blur-xl px-5 py-2 rounded-full inline-block border border-white/20">
               <span className="text-[10px] font-black text-blue-300 uppercase tracking-[0.4em] font-mono">STEP {currentScene + 1} // {scene.title}</span>
            </div>
            
            <div className="flex justify-center flex-col items-center gap-6">
               <motion.div 
                 animate={{ 
                   y: [0, -15, 0],
                   scale: [1, 1.05, 1],
                   rotate: [0, 3, -3, 0]
                 }}
                 transition={{ 
                   duration: 5, 
                   repeat: Infinity,
                   ease: "easeInOut"
                 }}
                 className="w-40 h-40 bg-gradient-to-br from-blue-500/30 to-purple-500/30 rounded-full flex items-center justify-center text-6xl border border-white/20 shadow-[0_0_80px_rgba(59,130,246,0.2)]"
               >
                  {scene.emoji}
               </motion.div>
               
               <div className="space-y-4">
                 <h3 className="text-3xl font-black text-white leading-tight tracking-tight">{scene.description}</h3>
                 <motion.p 
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   transition={{ delay: 1 }}
                   className="text-sm text-blue-200/60 font-mono tracking-wide"
                 >
                   &gt; {scene.animationHint}
                 </motion.p>
               </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Video Controls / Overlay */}
        <div className="absolute inset-x-0 bottom-0 p-8 bg-gradient-to-t from-black/80 to-transparent">
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between text-white/60 text-[10px] font-black tracking-widest uppercase mb-1">
               <span>Scene {currentScene + 1} of {total}</span>
               <span>{Math.floor((currentScene * SCENE_DURATION + (progress * SCENE_DURATION / 100)) / 1000)}s / 60s</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
               <motion.div 
                 className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]"
                 animate={{ width: `${progress}%` }}
                 transition={{ duration: 0.1, ease: "linear" }}
               />
            </div>
            <div className="flex items-center justify-center gap-6">
               <button 
                 onClick={() => {
                   if (currentScene > 0) {
                     setCurrentScene(currentScene - 1);
                     setProgress(0);
                   }
                 }}
                 disabled={currentScene === 0}
                 className="text-white/40 hover:text-white transition-colors disabled:opacity-0"
               >
                 <ChevronLeft className="w-6 h-6" />
               </button>
               
               <button 
                 onClick={() => setIsPlaying(!isPlaying)}
                 className="w-14 h-14 bg-white rounded-full flex items-center justify-center text-black hover:scale-110 transition-transform active:scale-95 shadow-xl"
               >
                 {isPlaying ? <Clock className="w-6 h-6" /> : <RefreshCcw className="w-6 h-6" />}
               </button>

               <button 
                 onClick={() => {
                   if (currentScene < total - 1) {
                     setCurrentScene(currentScene + 1);
                     setProgress(0);
                   }
                 }}
                 disabled={currentScene === total - 1}
                 className="text-white/40 hover:text-white transition-colors disabled:opacity-0"
               >
                 <ChevronRight className="w-6 h-6" />
               </button>
            </div>
          </div>
        </div>

        <div className="absolute top-8 left-8 flex items-center gap-3">
           <div className="flex items-center gap-2 px-3 py-1 bg-red-500 rounded-md text-white text-[9px] font-black tracking-widest uppercase">
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
              LIVE BREAKDOWN
           </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-8 bg-white border border-slate-100 rounded-[32px] group hover:border-blue-500/20 transition-all shadow-sm">
           <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 mb-6 group-hover:scale-110 transition-transform">
              <Star className="w-5 h-5" />
           </div>
           <h4 className="text-base font-black text-slate-800 mb-2 tracking-tight">Concept Visualization</h4>
           <p className="text-xs text-slate-500 leading-relaxed font-medium">This visual summary uses AI-generated scenes to help you visualize complex concepts from your study materials in exactly 60 seconds.</p>
        </div>
        <div className="p-8 bg-white border border-slate-100 rounded-[32px] group hover:border-green-500/20 transition-all shadow-sm">
           <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center text-green-600 mb-6 group-hover:scale-110 transition-transform">
              <Trophy className="w-5 h-5" />
           </div>
           <h4 className="text-base font-black text-slate-800 mb-2 tracking-tight">Active Learning Goal</h4>
           <p className="text-xs text-slate-500 leading-relaxed font-medium">Watching the complete visual breakdown contributes to your total study time and earns you 'Visual Learner' XP milestones.</p>
        </div>
      </div>
    </div>
  );
}

const CertificationCard: React.FC<{ data: Certification }> = ({ data }) => {
  return (
    <div className="p-6 bg-white border-2 border-slate-100 rounded-[32px] shadow-sm relative overflow-hidden group hover:border-blue-200 transition-all">
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full -translate-y-12 translate-x-12 opacity-50 group-hover:scale-125 transition-transform" />
      <div className="relative flex items-center gap-6">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-blue-100">
          <Award className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em]">{data.certificateId}</p>
          <h4 className="text-lg font-extrabold text-slate-800">{data.title}</h4>
          <div className="flex items-center gap-4 text-xs text-slate-400 font-medium">
            <span>Score: {Math.round(data.score)}%</span>
            <span className="w-1 h-1 bg-slate-200 rounded-full" />
            <span>Awarded: {new Date(data.timestamp).toLocaleDateString()}</span>
          </div>
        </div>
        <button className="ml-auto p-3 bg-slate-50 text-slate-400 rounded-2xl hover:bg-blue-600 hover:text-white transition-all shadow-sm">
           <Download className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

function SimulationView({ data, onComplete }: { data: StudyData['simulation'], onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isRevealed, setIsRevealed] = useState(false);

  const currentStep = data.steps[step];

  const handleSelect = (idx: number) => {
    if (isRevealed) return;
    setSelectedOption(idx);
    setIsRevealed(true);
  };

  const next = () => {
    if (step < data.steps.length - 1) {
      setStep(step + 1);
      setSelectedOption(null);
      setIsRevealed(false);
    } else {
      onComplete();
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-12">
      <div className="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden">
        <div className="bg-slate-900 p-8 text-white relative">
          <div className="absolute top-6 right-8 text-[10px] font-black text-blue-400 uppercase tracking-widest font-mono">STEP {step + 1} / {data.steps.length}</div>
          <h2 className="text-2xl font-black mb-2">{data.title}</h2>
          <p className="text-slate-400 text-sm">{data.description}</p>
        </div>

        <div className="p-10 space-y-10">
          <div className="bg-slate-50 p-8 rounded-[32px] border border-slate-100 italic text-lg leading-relaxed text-slate-700">
             "{currentStep.scenario}"
          </div>

          <div className="grid gap-4">
             {currentStep.options.map((opt, i) => (
               <button
                 key={i}
                 onClick={() => handleSelect(i)}
                 className={cn(
                   "w-full p-6 rounded-[24px] border-2 text-left transition-all relative overflow-hidden group",
                   isRevealed 
                    ? opt.isCorrect ? "border-green-500 bg-green-50" : selectedOption === i ? "border-red-500 bg-red-50" : "border-slate-50 opacity-40"
                    : "border-slate-100 hover:border-blue-500 hover:bg-blue-50"
                 )}
               >
                 <div className="flex items-start gap-4">
                   <div className={cn(
                     "w-8 h-8 rounded-full flex items-center justify-center text-xs font-black shrink-0",
                     isRevealed 
                      ? opt.isCorrect ? "bg-green-500 text-white" : selectedOption === i ? "bg-red-500 text-white" : "bg-slate-200 text-slate-400"
                      : "bg-slate-100 text-slate-400 group-hover:bg-blue-500 group-hover:text-white"
                   )}>
                      {String.fromCharCode(65 + i)}
                   </div>
                   <div>
                     <p className="font-bold text-slate-800">{opt.label}</p>
                     <p className="text-sm text-slate-500 mt-1">{opt.description}</p>
                   </div>
                 </div>
                 
                 {isRevealed && selectedOption === i && (
                   <motion.div 
                     initial={{ height: 0, opacity: 0 }}
                     animate={{ height: 'auto', opacity: 1 }}
                     className="mt-6 pt-6 border-t border-current/10"
                   >
                     <p className="text-sm font-bold uppercase tracking-widest mb-2">{opt.isCorrect ? 'SUCCESS' : 'CONSEQUENCE'}</p>
                     <p className="text-sm leading-relaxed">{opt.outcome}</p>
                   </motion.div>
                 )}
               </button>
             ))}
          </div>

          {isRevealed && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex justify-center pt-4">
              <button 
                onClick={next}
                className="h-14 px-10 bg-slate-900 text-white rounded-full font-black uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl shadow-slate-200"
              >
                {step === data.steps.length - 1 ? 'Finish Simulation' : 'Continue to Next Scenario'}
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}

function VisualizationView({ data }: { data: StudyData['conceptMap'] }) {
  // Simple conceptual layout: Core in center, others around it if not specified
  return (
    <div className="max-w-5xl mx-auto py-12 space-y-12">
      <div className="bg-white p-12 rounded-[48px] border border-slate-100 shadow-2xl relative min-h-[600px] overflow-hidden">
        <div className="absolute top-12 left-12">
          <h3 className="text-3xl font-black text-slate-900">Concept Map</h3>
          <p className="text-sm text-slate-400 font-medium">Visualizing the structural relationships between key ideas.</p>
        </div>

        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
           <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orientation="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#6366f1" />
              </marker>
           </defs>
           {/* Simple static lines connecting nodes - in a real app would use a layout engine like D3 */}
           {data.links.map((link, i) => {
              // Real logic would calculate positions. Here we just show the structure in a grid/circle.
              return null; 
           })}
        </svg>

        <div className="relative h-full flex items-center justify-center pt-24">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8 w-full">
            {data.nodes.map((node) => (
              <motion.div
                key={node.id}
                whileHover={{ scale: 1.05, y: -5 }}
                className={cn(
                  "p-8 rounded-[32px] border-2 shadow-sm flex flex-col items-center text-center gap-4 relative group",
                  node.type === 'core' 
                    ? "bg-indigo-600 border-indigo-400 text-white shadow-indigo-100" 
                    : node.type === 'supporting'
                    ? "bg-white border-slate-200 text-slate-800"
                    : "bg-slate-50 border-slate-100 text-slate-500 scale-90"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-xl mb-2",
                  node.type === 'core' ? "bg-indigo-500" : "bg-slate-100"
                )}>
                  {node.type === 'core' ? '🧠' : node.type === 'supporting' ? '💡' : '📌'}
                </div>
                <div>
                  <h4 className="font-black leading-tight">{node.label}</h4>
                  <p className={cn(
                    "text-[10px] uppercase font-black tracking-widest mt-2",
                    node.type === 'core' ? "text-indigo-200" : "text-slate-400"
                  )}>
                    {node.type}
                  </p>
                </div>
                
                {/* Relationship Hints */}
                <div className="absolute -top-4 -right-4 bg-white border border-slate-100 shadow-sm px-3 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10">
                   <span className="text-[10px] font-bold text-slate-400">
                     {data.links.find(l => l.source === node.id || l.target === node.id)?.relationship || 'Concept'}
                   </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {['Hierarchy', 'Context', 'Synthesis'].map((term) => (
          <div key={term} className="p-6 bg-slate-50 border border-slate-100 rounded-[24px] text-center">
             <h5 className="font-bold text-slate-800 mb-1">{term}</h5>
             <p className="text-xs text-slate-400">Automated mapping of logical {term.toLowerCase()} structures.</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScheduleView({ timetable, userId }: { timetable: TimetableEntry[], userId: string }) {
  const [newEntry, setNewEntry] = useState({ day: 'Monday', startTime: '09:00', endTime: '10:00', subject: '' });
  const [isAdding, setIsAdding] = useState(false);

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  const handleAdd = async () => {
    if (!newEntry.subject || !userId) return;
    try {
      await addDoc(collection(db, 'timetable'), {
        userId,
        ...newEntry
      });
      setIsAdding(false);
      setNewEntry({ day: 'Monday', startTime: '09:00', endTime: '10:00', subject: '' });
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'timetable');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'timetable', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, 'timetable');
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-10 space-y-8">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="text-3xl font-bold text-slate-800">Study Schedule</h2>
          <p className="text-sm text-slate-500">Plan your week to stay consistent.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="px-6 py-3 bg-primary text-white rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
        >
          <Plus className="w-5 h-5" />
          <span>Add Slot</span>
        </button>
      </div>

      {isAdding && (
        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-slate-50 p-8 rounded-[32px] border border-slate-200 grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Day</label>
            <select 
              value={newEntry.day} 
              onChange={e => setNewEntry({...newEntry, day: e.target.value})}
              className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold"
            >
              {days.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Start</label>
            <input 
              type="time" 
              value={newEntry.startTime} 
              onChange={e => setNewEntry({...newEntry, startTime: e.target.value})}
              className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">End</label>
            <input 
              type="time" 
              value={newEntry.endTime} 
              onChange={e => setNewEntry({...newEntry, endTime: e.target.value})}
              className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold"
            />
          </div>
          <div className="space-y-2 md:col-span-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Subject</label>
            <input 
              type="text" 
              placeholder="e.g. Physics" 
              value={newEntry.subject} 
              onChange={e => setNewEntry({...newEntry, subject: e.target.value})}
              className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold"
            />
          </div>
          <div className="flex gap-2">
            <button onClick={handleAdd} className="flex-1 p-3 bg-primary text-white rounded-xl font-bold text-sm">Save</button>
            <button onClick={() => setIsAdding(false)} className="px-4 p-3 bg-slate-200 text-slate-600 rounded-xl font-bold text-sm">Cancel</button>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-7 gap-6">
        {days.map(day => (
          <div key={day} className="space-y-4">
            <div className="pb-2 border-b-2 border-slate-100">
               <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{day.substring(0, 3)}</span>
            </div>
            <div className="space-y-3">
              {timetable.filter(e => e.day === day).sort((a,b) => a.startTime.localeCompare(b.startTime)).map(entry => (
                <div key={entry.id} className="p-4 bg-white border border-border-base rounded-2xl shadow-sm hover:border-primary/20 transition-all group relative">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-800 leading-tight">{entry.subject}</p>
                    <p className="text-[10px] text-slate-400 font-medium">{entry.startTime} - {entry.endTime}</p>
                  </div>
                  <button 
                    onClick={() => handleDelete(entry.id)}
                    className="absolute top-2 right-2 p-1.5 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {timetable.filter(e => e.day === day).length === 0 && (
                <div className="h-12 border-2 border-dashed border-slate-100 rounded-2xl" />
              )}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function StudyContent({ data, profile, pdfText, pages, fileName, onFinished }: { data: StudyData, profile: UserProfile | null, pdfText: string, pages: PdfPage[], fileName: string, onFinished: (type: SessionRecord['type'], score: string, status: string) => void }) {
  const [currentView, setCurrentView] = useState<'summary' | 'flashcards' | 'quiz' | 'search' | 'video' | 'simulation' | 'viz'>('summary');
  const [showRaw, setShowRaw] = useState(false);

  useEffect(() => {
    // Basic interaction tracking
    if (currentView === 'summary') onFinished('summary', '-', 'Read');
  }, [currentView]);

  return (
    <div className="space-y-8 pb-20">
      {/* Sub-tabs */}
      <div className="flex gap-3 border-b border-slate-100 sticky top-20 bg-white/80 backdrop-blur-md py-4 z-20">
        <SubTab active={currentView === 'summary'} label="Overview" icon={FileText} onClick={() => setCurrentView('summary')} />
        <SubTab active={currentView === 'flashcards'} label="Flashcards" icon={Brain} onClick={() => setCurrentView('flashcards')} />
        <SubTab active={currentView === 'quiz'} label="Practice Quiz" icon={CheckCircle2} onClick={() => setCurrentView('quiz')} />
        <SubTab active={currentView === 'search'} label="Search" icon={Search} onClick={() => setCurrentView('search')} />
        <SubTab active={currentView === 'video'} label="Animated Video" icon={Video} onClick={() => setCurrentView('video')} />
        <SubTab active={currentView === 'simulation'} label="Simulation" icon={RotateCcw} onClick={() => setCurrentView('simulation')} />
        <SubTab active={currentView === 'viz'} label="Visualization" icon={Star} onClick={() => setCurrentView('viz')} />
      </div>

      <AnimatePresence mode="wait">
        {currentView === 'summary' && (
          <motion.div key="summary" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 lg:grid-cols-[1.5fr_1fr] gap-8 items-start">
            <div className="space-y-8">
              <div className="bg-slate-900 text-white p-10 rounded-[48px] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none">
                   <FileText size={200} />
                </div>
                <div className="relative z-10 space-y-8">
                  <div className="space-y-2">
                    <h2 className="text-[10px] font-mono text-slate-500 uppercase tracking-[0.4em]">Neural Analysis Results</h2>
                    <h2 className="text-4xl font-serif italic font-black text-white tracking-tight">Synthesis Complete</h2>
                  </div>
                  
                  <div className="p-6 bg-white/5 border border-white/10 rounded-[32px] space-y-4 backdrop-blur-sm">
                    <div className="flex items-center gap-2 text-[10px] font-black tracking-widest uppercase text-slate-500">
                       <div className="w-4 h-[1px] bg-slate-700" />
                       Primary Source
                    </div>
                    <p className="text-xl font-serif italic text-white/90 leading-tight">
                      "{data.verification.subject || fileName}"
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <div className="px-4 py-2 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                       <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                       Grounding: {data.verification.trustScore}%
                    </div>
                    {data.verification.sourceDNA?.map(dna => (
                      <div key={dna} className="px-4 py-2 bg-primary/20 rounded-full text-[10px] font-black text-primary uppercase tracking-widest border border-primary/20">
                        {dna}
                      </div>
                    ))}
                  </div>

                  <div className="pt-8 border-t border-white/5">
                    <div className="flex items-center gap-2 text-slate-500 text-[10px] font-black tracking-widest uppercase mb-4">
                       <div className="w-4 h-[1px] bg-slate-700" />
                       Core Verification
                    </div>
                    <p className="text-base font-serif italic text-slate-300 relative pl-8 leading-relaxed">
                      <span className="absolute left-0 top-0 text-4xl text-slate-700 font-serif leading-none italic">"</span>
                      {data.verification.illustrativeQuote}
                    </p>
                    <p className="text-[11px] font-mono text-slate-500 italic mt-6 border-l border-slate-800 pl-4 py-1">
                      LOGICAL_CHECK_ID: {data.verification.logicalCheck}
                    </p>
                  </div>
                </div>
              </div>

              <section className="bg-white p-10 rounded-[32px] border border-slate-100 shadow-xl shadow-slate-200/50">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-2xl font-black text-slate-800 tracking-tight">Executive Summary</h3>
                  <div className="flex items-center gap-2">
                     <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                     <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Live Document Feed</span>
                  </div>
                </div>
                <div className="text-slate-600 leading-relaxed text-base font-medium">
                  <Markdown>{data.summary}</Markdown>
                </div>
              </section>

              <section className="bg-white p-10 rounded-[32px] border border-slate-100 shadow-xl shadow-slate-200/50">
                <div className="flex items-center justify-between mb-8">
                   <h3 className="text-2xl font-black text-slate-800 tracking-tight">Analytical Deep-Dive</h3>
                   <div className="flex gap-2">
                     <button 
                      onClick={() => setShowRaw(!showRaw)}
                      className="px-4 py-2 bg-slate-50 hover:bg-slate-100 rounded-full text-[10px] font-black text-slate-500 uppercase tracking-widest transition-all"
                     >
                       {showRaw ? "Return to Analysis" : "Audit Source Text"}
                     </button>
                   </div>
                </div>
                
                {showRaw ? (
                   <div className="bg-slate-900 p-8 rounded-2xl font-mono text-[12px] text-green-400/80 overflow-auto max-h-[600px] leading-relaxed">
                      <div className="mb-4 text-green-500/50 border-b border-green-500/20 pb-2">--- START RAW TEXT DUMP ---</div>
                      {pdfText}
                      <div className="mt-4 text-green-500/50 border-t border-green-500/20 pt-2">--- END RAW TEXT DUMP ---</div>
                   </div>
                ) : (
                  <div className="prose prose-slate max-w-none text-slate-700 leading-relaxed text-sm space-y-4">
                    <Markdown>{data.detailedAnalysis}</Markdown>
                  </div>
                )}
              </section>

              <section className="bg-white p-8 rounded-[24px] border border-border-base shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Key Learning Points</h3>
                <div className="space-y-4">
                  {data.keyPoints.map((point, i) => (
                    <div key={i} className="flex gap-4 group">
                      <span className="text-primary font-black text-lg">•</span>
                      <p className="text-slate-600 text-sm font-medium leading-normal">{point}</p>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            <div className="space-y-8">
              <section className="bg-white p-8 rounded-[24px] border border-border-base shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-6" >Progress Overview</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-6 rounded-[20px] text-center">
                    <span className="text-2xl font-extrabold text-primary block">{Math.ceil(pdfText.split(/\s+/).length / 200)}m</span>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Est. Read</span>
                  </div>
                  <div className="bg-slate-50 p-6 rounded-[20px] text-center">
                    <span className="text-2xl font-extrabold text-primary block">2.4k</span>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total XP</span>
                  </div>
                </div>
              </section>

              <section className="bg-white p-8 rounded-[24px] border border-border-base shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Achievement Progress</h3>
                <div className="flex gap-3 flex-wrap">
                   {AVAILABLE_BADGES.slice(0, 4).map((badge) => {
                     const isEarned = profile?.badges?.includes(badge.id);
                     return (
                       <div 
                         key={badge.id} 
                         title={badge.name}
                         className={cn(
                           "w-12 h-12 rounded-full flex items-center justify-center text-xl shadow-sm border transition-all",
                           isEarned ? `${badge.color} border-transparent` : "bg-slate-50 border-slate-100 opacity-30 grayscale"
                         )}
                       >
                         {badge.icon}
                       </div>
                     );
                   })}
                </div>
              </section>
            </div>
          </motion.div>
        )}

        {currentView === 'video' && (
          <VisualSummaryView scenes={data.visualSummary} onComplete={() => onFinished('summary', '-', 'Watched Video')} />
        )}

        {currentView === 'simulation' && (
          <SimulationView data={data.simulation} onComplete={() => onFinished('summary', '-', 'Completed Simulation')} />
        )}

        {currentView === 'viz' && (
          <VisualizationView data={data.conceptMap} />
        )}

        {currentView === 'flashcards' && (
          <FlashcardView flashcards={data.flashcards} onComplete={() => onFinished('flashcards', '-', 'Studied')} />
        )}

        {currentView === 'quiz' && (
          <QuizView mcqs={data.mcqs} onComplete={(score) => onFinished('quiz', score.toString(), 'Completed')} />
        )}

        {currentView === 'search' && (
          <SearchView searchExamples={data.searchExamples} pages={pages} />
        )}
      </AnimatePresence>
    </div>
  );
}

function SearchView({ searchExamples, pages }: { searchExamples: string[], pages: PdfPage[] }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{ text: string, page: number }[]>([]);

  const handleSearch = (q: string) => {
    setQuery(q);
    if (!q.trim() || q.length < 3) {
      setResults([]);
      return;
    }

    const keywords = q.toLowerCase().split(' ').filter(k => k.length > 2);
    const searchResults: { text: string, page: number }[] = [];

    pages.forEach(p => {
      const paragraphs = p.text.split('\n').filter(para => para.length > 20);
      paragraphs.forEach(para => {
        if (keywords.some(k => para.toLowerCase().includes(k))) {
          searchResults.push({ text: para.trim(), page: p.pageNumber });
        }
      });
    });

    setResults(searchResults.slice(0, 15));
  };

  return (
    <motion.div key="search" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-3xl mx-auto space-y-10 py-12">
      <div className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-blue-500/20 rounded-[28px] blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
        <div className="relative bg-white border border-border-base rounded-[24px] shadow-sm overflow-hidden">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-300 group-focus-within:text-primary transition-colors" />
          <input 
            type="text" 
            value={query}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search deep within results..."
            className="w-full h-18 pl-18 pr-6 focus:outline-none font-bold text-lg placeholder:text-slate-300"
          />
        </div>
      </div>

      {results.length > 0 ? (
        <div className="space-y-6">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] px-2 flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            Found {results.length} Analytical Matches
          </h4>
          <div className="grid gap-4">
            {results.map((res, i) => (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                key={i} 
                className="p-6 bg-white border border-slate-100 rounded-[24px] shadow-sm hover:border-slate-200 transition-all group"
              >
                <p className="text-slate-600 text-sm leading-relaxed mb-4">
                  ...{res.text.length > 250 ? res.text.substring(0, 250) + '...' : res.text}
                </p>
                <div className="flex items-center justify-between">
                   <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-3 py-1 rounded-full border border-blue-100 italic">Page {res.page} Analysis</span>
                   <button className="text-xs font-bold text-primary hover:underline">Reference in PDF</button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      ) : query.length > 3 ? (
        <div className="py-20 text-center space-y-4">
           <div className="text-4xl">🔍</div>
           <p className="text-slate-400 font-medium">No direct matches found in current document analysis.</p>
        </div>
      ) : (
        <div className="space-y-6">
          <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] px-2">Knowledge Discovery Examples</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {searchExamples.map((ex, i) => (
              <button 
                key={i} 
                onClick={() => handleSearch(ex)}
                className="p-5 bg-white border border-slate-100 hover:border-blue-200 rounded-[24px] text-left transition-all group shadow-sm bg-gradient-to-br from-white to-slate-50/30"
              >
                <div className="flex justify-between items-start">
                  <span className="text-slate-700 font-bold text-sm leading-snug">"{ex}"</span>
                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-primary transition-colors" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}

function SubTab({ active, label, icon: Icon, onClick }: { active: boolean, label: string, icon: any, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-2 px-6 py-3 rounded-full transition-all text-sm font-bold border whitespace-nowrap",
        active 
          ? "bg-slate-900 text-white border-slate-900 shadow-xl shadow-slate-300" 
          : "bg-white text-slate-500 border-slate-100 hover:border-slate-300 hover:text-slate-800"
      )}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );
}

function FlashcardView({ flashcards, onComplete }: { flashcards: StudyData['flashcards'], onComplete: () => void }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [direction, setDirection] = useState(0); // -1 for left, 1 for right

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        prevCard();
      } else if (e.key === 'ArrowRight' || e.key === ' ') {
        if (e.key === ' ') {
          e.preventDefault();
          setIsFlipped(!isFlipped);
        } else {
          nextCard();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, isFlipped]);

  const nextCard = () => {
    if (currentIndex < flashcards.length - 1) {
      setDirection(1);
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    } else {
      onComplete();
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setDirection(-1);
      setCurrentIndex(currentIndex - 1);
      setIsFlipped(false);
    }
  };

  const current = flashcards[currentIndex];
  const progress = ((currentIndex + 1) / flashcards.length) * 100;

  return (
    <div className="flex flex-col items-center justify-center py-12 gap-10 max-w-2xl mx-auto">
      {/* Progress Header */}
      <div className="w-full space-y-4">
        <div className="flex justify-between items-end">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Study Progress</span>
            <p className="text-sm font-bold text-slate-700">Card {currentIndex + 1} of {flashcards.length}</p>
          </div>
          <span className="text-xs font-bold text-primary bg-indigo-50 px-3 py-1 rounded-full">
            {Math.round(progress)}% Complete
          </span>
        </div>
        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full bg-primary"
          />
        </div>
      </div>

      <div className="perspective-1000 w-full h-[400px] relative">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
             key={currentIndex}
             custom={direction}
             variants={{
               enter: (dir: number) => ({ x: dir > 0 ? 100 : -100, opacity: 0, rotateY: 0 }),
               center: { x: 0, opacity: 1 },
               exit: (dir: number) => ({ x: dir < 0 ? 100 : -100, opacity: 0 })
             }}
             initial="enter"
             animate="center"
             exit="exit"
             transition={{ duration: 0.3, ease: "easeOut" }}
             className="w-full h-full"
          >
            <motion.div
               animate={{ rotateY: isFlipped ? 180 : 0 }}
               transition={{ duration: 0.6, type: "spring", stiffness: 260, damping: 20 }}
               className="relative w-full h-full preserve-3d cursor-pointer group"
               onClick={() => setIsFlipped(!isFlipped)}
            >
              {/* Front Side */}
              <div className="absolute inset-0 backface-hidden bg-white border border-border-base rounded-[32px] p-12 flex flex-col items-center justify-center text-center shadow-xl shadow-indigo-100/10 group-hover:border-primary/30 transition-colors">
                <div className="absolute top-8 left-1/2 -translate-x-1/2 flex items-center gap-2">
                   <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
                   <span className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em]">Front / Question</span>
                </div>
                
                <h3 className="text-2xl md:text-3xl font-extrabold text-slate-800 leading-tight">
                  {current.front}
                </h3>
                
                <div className="absolute bottom-10 flex flex-col items-center gap-3">
                  <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-full text-slate-400 group-hover:bg-indigo-50 group-hover:text-primary transition-colors">
                    <RefreshCcw className="w-4 h-4" />
                    <span className="text-[11px] font-bold uppercase tracking-wider">Click to see back</span>
                  </div>
                  <p className="text-[10px] text-slate-300 font-medium">Tip: You can also use [Space] to flip</p>
                </div>
              </div>

              {/* Back Side */}
              <div className="absolute inset-0 backface-hidden bg-primary text-white rounded-[32px] p-12 flex flex-col items-center justify-center text-center rotate-y-180 shadow-2xl shadow-indigo-500/20">
                <div className="absolute top-8 left-1/2 -translate-x-1/2 flex items-center gap-2">
                   <div className="w-1.5 h-1.5 bg-white rounded-full opacity-50" />
                   <span className="text-[11px] font-bold text-white/60 uppercase tracking-[0.2em]">Back / Explanation</span>
                </div>
                
                <p className="text-lg md:text-xl font-medium leading-relaxed">
                  {current.back}
                </p>

                <div className="absolute bottom-10 px-4 py-2 bg-white/10 rounded-full backdrop-blur-sm border border-white/20">
                    <span className="text-[11px] font-bold uppercase tracking-wider">Solution Revealed</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex items-center gap-4 w-full justify-between sm:justify-center">
        <button 
          onClick={prevCard}
          className="flex items-center gap-2 px-6 py-4 rounded-[20px] border border-border-base bg-white hover:bg-slate-50 disabled:opacity-30 disabled:hover:bg-white transition-all shadow-sm font-bold text-sm text-slate-700"
          disabled={currentIndex === 0}
        >
          <ChevronLeft className="w-5 h-5 text-primary" />
          <span className="hidden sm:inline">Previous</span>
        </button>
        
        <div className="flex gap-2">
           <button 
             onClick={() => setIsFlipped(!isFlipped)}
             className="px-6 py-4 rounded-[20px] border border-border-base bg-white hover:bg-slate-50 transition-all shadow-sm font-extrabold text-sm text-primary flex items-center gap-2"
           >
             <RefreshCcw className="w-5 h-5" />
             <span className="hidden sm:inline">Flip</span>
           </button>
        </div>

        <button 
          onClick={nextCard}
          className="flex items-center gap-2 px-6 py-4 rounded-[20px] bg-primary text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 font-bold text-sm"
        >
          <span className="hidden sm:inline">{currentIndex === flashcards.length - 1 ? 'Finish' : 'Next Card'}</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      <div className="flex items-center gap-6 pt-4 border-t border-slate-100 w-full justify-center">
         <div className="flex items-center gap-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <div className="flex items-center gap-1.5">
               <kbd className="px-2 py-1 bg-slate-100 rounded-md border border-slate-200">←</kbd>
               <span>Prev</span>
            </div>
            <div className="flex items-center gap-1.5">
               <kbd className="px-2 py-1 bg-slate-100 rounded-md border border-slate-200">Space</kbd>
               <span>Flip</span>
            </div>
            <div className="flex items-center gap-1.5">
               <kbd className="px-2 py-1 bg-slate-100 rounded-md border border-slate-200">→</kbd>
               <span>Next</span>
            </div>
         </div>
      </div>
    </div>
  );
}

function QuizView({ mcqs, onComplete }: { mcqs: StudyData['mcqs'], onComplete: (score: number) => void }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const current = mcqs[currentIndex];

  const handleAnswer = (key: string) => {
    if (selectedAnswer) return;
    setSelectedAnswer(key);
    const correct = key === current.answer;
    if (correct) setScore(s => s + 1);
    
    setTimeout(() => {
      if (currentIndex < mcqs.length - 1) {
        setCurrentIndex(currentIndex + 1);
        setSelectedAnswer(null);
      } else {
        setShowResult(true);
        onComplete(score + (correct ? 1 : 0));
      }
    }, 1500);
  };

  if (showResult) {
    return (
      <div className="text-center py-20 space-y-6">
        <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-8">
          <Trophy className="w-12 h-12 text-blue-600" />
        </div>
        <h2 className="text-4xl font-bold">Quiz Complete!</h2>
        <p className="text-2xl text-zinc-500">You scored {score} out of {mcqs.length}</p>
        <div className="flex justify-center gap-4 mt-12">
           <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100 flex flex-col items-center gap-2">
              <span className="text-xs font-mono text-zinc-400">XP EARNED</span>
              <span className="font-bold text-xl text-blue-600">+{score * 10}</span>
           </div>
           <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100 flex flex-col items-center gap-2">
              <span className="text-xs font-mono text-zinc-400">ACCURACY</span>
              <span className="font-bold text-xl text-zinc-900">{Math.round((score / mcqs.length) * 100)}%</span>
           </div>
        </div>
        <button 
          onClick={() => { setCurrentIndex(0); setScore(0); setShowResult(false); setSelectedAnswer(null); }}
          className="mt-12 px-8 py-3 bg-zinc-900 text-white rounded-xl font-medium"
        >
          Retake Quiz
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-12">
      <div className="bg-white p-10 rounded-[24px] border border-border-base shadow-lg">
        <div className="flex items-center justify-between mb-10">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Question {currentIndex + 1} / {mcqs.length}</span>
          <div className="w-48 h-1.5 bg-slate-100 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${((currentIndex + 1) / mcqs.length) * 100}%` }}
              className="h-full bg-primary" 
            />
          </div>
        </div>

        <h3 className="text-xl font-extrabold text-slate-800 mb-8 leading-tight">{current.question}</h3>

        <div className="grid gap-3">
          {Object.entries(current.options).map(([key, value]) => {
            const isSelected = selectedAnswer === key;
            const isCorrect = key === current.answer;
            const showColors = selectedAnswer !== null;

            return (
              <button
                key={key}
                onClick={() => handleAnswer(key)}
                disabled={selectedAnswer !== null}
                className={cn(
                  "w-full p-4 text-left rounded-[16px] border transition-all flex items-center justify-between group",
                  !showColors && "border-border-base bg-white hover:border-primary/50 hover:bg-indigo-50/10",
                  showColors && isCorrect && "border-green-500 bg-green-50 text-green-900",
                  showColors && isSelected && !isCorrect && "border-red-500 bg-red-50 text-red-900",
                  showColors && !isSelected && !isCorrect && "opacity-50"
                )}
              >
                <div className="flex items-center gap-4">
                  <span className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs transition-all",
                    !showColors ? "bg-slate-100 text-slate-400 group-hover:bg-indigo-600 group-hover:text-white" : (isCorrect ? "bg-green-200 text-green-700" : "bg-slate-200")
                  )}>
                    {key.toUpperCase()}
                  </span>
                  <span className="font-semibold text-sm">{value}</span>
                </div>
                {showColors && isCorrect && <span className="text-[11px] font-bold text-green-600">Correct</span>}
              </button>
            );
          })}
        </div>

        {!selectedAnswer && (
          <button className="w-full mt-10 py-4 bg-primary text-white rounded-[16px] font-bold shadow-lg shadow-indigo-100 hover:scale-[1.02] transition-transform">
            Check Answer
          </button>
        )}
      </div>
    </div>
  );
}
