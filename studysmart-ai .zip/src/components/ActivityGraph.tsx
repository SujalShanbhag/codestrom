import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';

interface ActivityGraphProps {
  userId: string;
}

export const ActivityGraph: React.FC<ActivityGraphProps> = ({ userId }) => {
  const [data, setData] = React.useState<any[]>([]);

  React.useEffect(() => {
    if (!userId) return;

    const activityRef = collection(db, 'users', userId, 'activity');
    const q = query(activityRef, orderBy('date', 'desc'), limit(7));

    const unsubscribe = onSnapshot(q, (snap) => {
      const activityData = snap.docs.map(doc => ({
        day: new Date(doc.data().date).toLocaleDateString(undefined, { weekday: 'short' }),
        hours: doc.data().hours,
        rawDate: doc.data().date
      })).reverse();
      
      setData(activityData);
    });

    return () => unsubscribe();
  }, [userId]);

  return (
    <div className="w-full h-64 mt-4">
      {data.length > 0 ? (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis 
              dataKey="day" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 500 }}
              dy={10}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 500 }}
            />
            <Tooltip 
              cursor={{ fill: '#f8fafc' }}
              contentStyle={{ border: 'none', borderRadius: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', fontSize: '12px' }}
            />
            <Bar 
              dataKey="hours" 
              radius={[6, 6, 0, 0]} 
              barSize={32}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={index === data.length - 1 ? '#4f46e5' : '#e2e8f0'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      ) : (
        <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-slate-100 rounded-3xl text-slate-400 p-8 space-y-2">
            <p className="font-bold text-sm">No recent activity</p>
            <p className="text-xs">Log study hours to see your progress graph!</p>
        </div>
      )}
    </div>
  );
};
