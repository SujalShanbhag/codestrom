import * as pdfjs from 'pdfjs-dist';

// Define worker source for pdfjs
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

export interface PdfPage {
  text: string;
  pageNumber: number;
}

export async function extractTextFromPdf(file: File): Promise<{ fullText: string, pages: PdfPage[] }> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;
  let fullText = '';
  const pages: PdfPage[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const pageText = textContent.items
      .map((item: any) => item.str)
      .join(' ');
    
    fullText += pageText + '\n';
    pages.push({ text: pageText, pageNumber: i });
  }

  return { fullText: fullText.trim(), pages };
}
